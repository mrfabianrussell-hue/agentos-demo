# Live Insights — v4.1

Open **Insights** in the left navigation after connecting. Rules are evaluated by the same backend engine that chooses commands. The dashboard displays its decision records, not a separate execution model.

## Read a card

- Current measurement, comparison and threshold distance: expressed in calls, agents, seconds, records or percentage points as appropriate. This is not a probability of triggering.
- Approaching threshold: a non-matching value within 20% of a nonzero threshold. Zero thresholds do not have an approaching band. Strict greater/less comparisons do not match at equality.
- Condition hold: the observed sustained duration against the configured duration. This is frozen at the last evaluation, not a promise of execution. It resets when conditions fail or observations are unavailable. A gap over 60 seconds between evaluations also resets hold and recovery timers.
- Execution state: read-only/control modes show monitoring only. Global pause also blocks automatic commands. A satisfied condition does not override these controls.
- Eligibility: counts and per-campaign reasons come from the engine after rule precedence and duplicate action resolution. Actual dispatch rechecks authorization and current conditions.
- Recovery: owned campaigns, confirmed stopped count, recovery hold and per-campaign blockers. Campaigns not stopped by this rule cannot be recovered by it. Expand measurements to see which selected sources have not recovered.
- Schedule: next execution in the rule timezone with countdown. Existing admission windows and exceptions still apply.

## Find what matters

The default view shows rules needing attention, including conditions holding/ready, recovery, approaching thresholds, unhealthy rules and schedules. All rules includes normally monitoring, paused and disabled rules. Search, filter and 12-card pages limit the amount shown. Expanded details and the search field remain intact during refresh.

Coverage reports missing/stale source values, unavailable targets, failed commands and rules with no eligible changes. No eligible changes can be normal, such as campaigns already being in the desired state; inspect the reasons.

Cards link to edit the rule, review its campaigns, pause/enable it, or search the Activity log. Pause automation has a confirmation explaining that it leaves running campaigns running and cannot withdraw commands already sent.

## Trends and events

Sources shared by several rules are sampled once, every 10 seconds when backend evaluations occur. Each source retains up to 360 samples / 60 minutes, in memory for the current connection. Only sources used by metric rules are sampled, capped at 2,500 sources. Reconnect/restart starts a new history. Missing/stale data and long observation gaps break the chart line; missing values are never replaced with zero.

Each card's compact graph identifies the source and metric it plots, displays the observed range and time interval, and marks the threshold with a dashed line. It is a representative measurement; expand live measurements to inspect all sources and conditions. The browser retrieves history only for the visible cards, at most 24 sources per request.

Recent events include hold starts/resets, recovery holds, newly confirmed stopped campaigns, recovery confirmations and unhealthy/recovery state transitions. They reflect observations made in this backend session; there is no retroactive history. Up to 500 events are retained, with the latest 100 displayed. The persistent Activity log remains the command audit.

## Rule review improvements

New rules begin with no source selected. Deliberately select compatible sources and review the action targets. Saving a rule displays enabled opposite-action rules sharing its targets. Overlap can be intentional, so the review explains precedence instead of rejecting all overlaps.

## Live verification

After installing, reconnect in read-only mode. Confirm that values and units match Five9. Create a disabled rule, review sources/targets, then use a small authorized campaign set to verify hold, stop and recovery behavior. All included automated tests use fixtures; actual live-domain verification remains necessary.
