# First live check after the update

1. Stop the previous backend, preserve its data, and start v4. See START-HERE.md for upgrade steps.
2. Connect in **read-only** mode. Confirm the expected campaign count and names.
3. Open Connections. Let feeds initialize; confirm CampaignState freshness and at least one expected skill or campaign metric source. If a feed fails, download diagnostics and note its error. An empty update should now cause a snapshot, not permanently prevent other feeds from initializing.
4. Search a campaign prefix, select all matches, then change the search. Confirm the selection count remains correct. Review the selected names.
5. Create a disabled rule for one noncritical campaign. Select one or more relevant skills. Inspect the review summary, target list and recovery thresholds. Set the intended timezone and operating hours.
6. Review decisions in read-only mode. Confirm the units and values against Five9. Missing data must show unavailable, never zero.
7. Enable Live control and start/normal-stop one authorized campaign. Watch Requested → Accepted → Verified. Confirm active-call behavior in Five9.
8. Run a small reviewed bulk operation and inspect every job result. Cancel remaining items only while some are queued; sent commands may still complete.
9. Verify Force Stop visibility and its explicit acknowledgement. Only execute it on a campaign where disconnecting active calls is intended and authorized.
10. For automation, begin with a small campaign group and conservative thresholds. Enable Live automation, resume evaluation, and observe stop, cooldown and recovery. Confirm only campaigns owned by the rule restart and that manual holds/closing schedules block them.
11. Create a near-future schedule for the same small group. Confirm timezone, execution, per-target results and no second execution of the same occurrence. Add an excluded date and inspect the next run.
12. Switch to read-only or disconnect when finished. Back up data/state.json with the backend stopped.

Provide the downloaded diagnostics and the relevant activity entries if live values or outcomes differ from expectations. Never include your Five9 password or local unlock code.
