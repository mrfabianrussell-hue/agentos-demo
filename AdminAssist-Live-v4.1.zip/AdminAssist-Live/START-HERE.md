# Admin Assist Live v4.1.0 — start here

This package is a runnable backend plus the Admin Assist interface. It makes real HTTPS requests to Five9. The hosted ChatGPT Site remains the separate demonstration version.

## Upgrading from v3

1. Stop the old backend terminal. Back up its `data` folder.
2. Extract this ZIP into a new folder. Copy the old `data/state.json` into the new package’s `data` folder. Do not copy `server.lock`.
3. Start the new edition, reconnect in read-only mode, and inspect campaigns, sources, groups, rules, and schedules.
4. Re-enable live control or automation only after reviewing the live state. Existing rule configuration is retained; live ownership and pending operations are reconciled after reconnect.

See `INSIGHTS-GUIDE.md` for the new dashboard and `V4-UPDATE-GUIDE.md` for operating controls and `LIVE-VERIFICATION.md` for the first-domain check.

## Start on Windows

1. Install **Node.js 22 or later** if it is not already installed. Check with `node --version` in a terminal.
2. Extract the entire ZIP to a local folder. Do not run directly inside the ZIP.
3. Double-click **Start-Admin-Assist.cmd**. No `npm install` is needed.
4. Open **http://127.0.0.1:8787** in your browser.
5. Copy the **local access code** printed in the terminal into the unlock screen. This code is not your Five9 password.
6. Open **Connections**, enter a display name, region, Five9 username and password, then choose **Connect in read-only mode**.

On macOS/Linux, run `./start.sh`, or run `node server.mjs` from the extracted folder. Keep the process running while using live statistics or automation.

## Five9 account requirements

Use a dedicated account authorized for the intended domain:

- Supervisor designation.
- **Execute Web API requests (legacy)** under Domain Supervisor.
- Complete the account's initial Supervisor browser login/security-question setup first.
- Campaign start/stop permissions for the operations you intend to enable.
- Visibility into the campaigns and skills you intend to administer.

The supplied Statistics API guide explicitly says **API-only users cannot be used** for that service. This package uses Supervisor SOAP with HTTP Basic authentication. A passwordless/SSO-only account that cannot authenticate to this SOAP service will not work without an appropriately provisioned integration account.

The SOAP account determines the accessible domain. There is no arbitrary domain-ID override. Verify the campaign names after connection. Profiles and saved configuration are separated by region and username. Only one live connection is active per backend process. Disconnect before connecting another account.

## Endpoint and statistics settings

The default is the documented **v11 SupervisorWebService** endpoint. Other documented choices in the UI are v10.2, v10, v9.5 and v4. The uploaded manual lists different service names for newer versions; this implementation deliberately uses the documented SupervisorWebService routes instead of guessing v12/v13 URLs.

Regions map to Five9 HTTPS API hosts. A domain's permissions, enabled API versions and regional availability still require validation with that domain. If a response indicates an endpoint/version problem, confirm the supported route with Five9 before changing the version.

Statistics use `CurrentDay`, `Minutes30`, shift start midnight, and the entered fixed UTC offset. The default offset comes from your browser. Reconnect when that aggregate-statistics offset needs changing after daylight-saving transitions. Rules with scheduled times separately use an IANA time zone and handle daylight-saving changes.

## First live verification

1. Confirm the campaign catalog belongs to the expected domain. This reads real data; no sample campaigns are added.
2. Let feeds initialize. Connections shows discovered columns and errors. Missing metrics remain unavailable rather than becoming zero.
3. From campaign details, optionally map a campaign to a skill to populate the workspace's shared queue/ready columns. Rule sources can directly monitor any available skill without that display mapping.
4. Create a small group and configure a disabled rule. Rules and groups are stored in the backend's `data/state.json`.
5. Review **Automations → View live decisions**. This uses real server time and statistics, not simulated values.
6. When ready, enable **Live campaign control** in Connections. You must enter the displayed confirmation phrase. Test one authorized, noncritical campaign and verify its final state.
7. For unattended rules, enable **Live automation**, then release the global pause under Automations. Enabled rules can now execute when eligible. Closing the browser does not stop them; stopping the backend does.

Keep the global pause active while reviewing configuration. To disable all API writes immediately, choose **Read-only**. To end the live session, choose **Disconnect & stop automation**.

## What this edition implements

- Live campaign discovery and state updates using CampaignState statistics.
- Skill queue/ready/current-wait statistics and campaign service-level, abandonment, and available-record measures where those columns are returned.
- Background individual and bulk start/normal-stop jobs. Manual Force Stop requires a separate active-call-disconnection acknowledgement.
- Searchable bulk selection, reusable campaign groups, multi-rule campaign additions, saved views, and group-linked or fixed-list rules.
- Server-side multi-source metric rules, sustained durations, per-campaign cooldowns, bounded retries, operating hours, date exceptions and manual overrides.
- Server-side one-time and weekly scheduled rules.
- Optional recovery that resumes only campaigns stopped by the responsible monitoring rule.
- Shared server-side configuration and a rolling 5,000-entry audit log.
- Persistent rule/runtime data while the process runs. Restart deliberately clears live execution state, requires account login and starts paused/read-only again.

A successful SOAP response means **accepted**, not necessarily completed. The application shows transitional states and records completion when Five9 confirms it. Uncertain actions are not blindly retried. Missing or stale feeds block dependent rules. Definite rate-limit rejection can receive bounded retries after fresh state and eligibility checks. Unknown outcomes are not automatically replayed. If a transition remains pending for two minutes, inspect Five9 and use the campaign’s unresolved-request review; it refreshes state, clears recovery ownership and applies a 15-minute hold.

## Important operating limits

- **This is a single-operator, loopback-only edition.** It binds to 127.0.0.1 and rejects nonlocal hosts and cross-origin requests. Do not expose it with a public tunnel, change the bind address or place it behind an internet proxy as a shortcut to multiuser hosting.
- **The process must remain running.** Machine sleep, shutdown, network loss or terminal closure interrupts polling and execution. Browser closure alone does not. Restart requires login and re-arming. Credentials are never stored on disk.
- **It has not been authenticated against your domain.** Automated tests use documented response fixtures and a mock HTTPS transport. You must validate live column formats, permissions, state behavior and limits on your account. Browser interaction and layout checks used a 660-campaign fixture. They are not evidence of authentication or successful commands against your live domain.
- **Automatic recovery attribution has a boundary.** Manual actions in this app clear recovery ownership. A separate administrator's direct action in Five9 cannot always be distinguished from an existing stopped state. Use this app for control while recovery is enabled, or disable recovery when other tools/users are controlling the same campaigns.
- **Scheduled execution is not a calling-compliance policy.** Configure approved dates, time zones, thresholds and campaign targets. Five9 permissions and campaign dialing settings remain authoritative. A scheduled batch must begin within a five-minute grace window. Once admitted, it may finish its original eligible target set for up to 60 minutes. Every command still checks current overrides, operating hours, and conflicting closing/opening schedules. Missed, unadmitted runs are not replayed. Pausing or leaving automation discards admitted batches.
- **No guaranteed exactly-once semantics across a crash.** Pending requests may have reached Five9 before an interruption. Restart disarms writes and clears recovery ownership to avoid replay; reconcile actual state before enabling again.
- **Quota handling is conservative, not entitlement discovery.** Requests are serialized with at least one second between request starts; stats updates use five-second long polling when idle and immediate polling while commands are queued, with per-type cursors. Commands are interleaved with feed refreshes. Bulk commands can take many minutes. Actual domain limits may be lower or shared with other integrations. HTTP 429 command rejection receives bounded retries; statistics errors use capped backoff. Permission/authentication failures require correcting access and reconnecting.
- **SOAP campaign identity is name-based.** Renaming a campaign changes its local identifier; review affected groups/rules afterward. Previously selected targets do not silently expand.

## Troubleshooting

| Symptom | What to check |
|---|---|
| Incorrect local code | Use the code from the current terminal session. Restart generates a new code unless configured otherwise. |
| 401/403 or SOAP permission fault | Supervisor role, Execute Web API requests (legacy), first login completion, credentials, account policy. |
| Login/session conflict | Dedicated account not shared with another Supervisor client. This application does not force-log-out another session. |
| No campaigns or skills | Account visibility, correct region/account, and discovered columns under Connections. |
| Metrics show unavailable | That source did not return the expected field or format. Check discovered columns; do not create rules assuming missing values are zero. |
| Cannot enable automation | CampaignState must be fresh and the account must have campaign permissions. Each rule separately requires its own sources to be fresh. |
| Campaign remains Starting/Stopping | Inspect Five9 and active calls. Normal stop waits for calls to finish. Do not repeatedly submit commands. |
| Settings conflict | Reload to get the current configuration revision, then reapply the edit. |
| Backend not reachable | Keep the terminal open, use 127.0.0.1:8787, check Node version and port availability. |
| Server lock after a crash | Stop any remaining backend process first. The backend removes a stale lock when it can verify the process is gone. Do not delete an active process's lock. |

## Files and developer handoff

- `server.mjs`: HTTP boundary, login/modes, API routes, action queue, polling and rule worker.
- `backend/five9.mjs`: Supervisor SOAP session/cookies, permissions, snapshots, deltas, commands and normalization.
- `backend/xml.mjs`: bounded SOAP XML parser; DTD/entity declarations rejected.
- `backend/execution.mjs`: retry eligibility checks and targeted runtime preservation.
- `backend/store.mjs`: atomic JSON persistence, single-process lock and configuration validation.
- `public/`: the live interface, shared rule engine, schedule and target logic.
- `tests/`: automated parser, transport, API boundary, state-store, targeting, schedule and recovery checks.

Run `npm test` to execute tests. No external npm packages are required.

Optional environment variables: `PORT` (default 8787), `ADMIN_ASSIST_DATA` (absolute data folder), `ADMIN_ASSIST_ACCESS_CODE` (a strong local operator access code). Do not set Five9 passwords in source or environment files; use the Connections form.

Back up `data/state.json` while the server is stopped. It contains campaign configuration and audit records, but no Five9 password. Protect access to the folder as business operational data.

A future multiuser/Azure deployment needs authenticated user roles, a secret vault, shared database and durable job coordination, HTTPS, and independently validated network access. This package provides the live local implementation and adapter code; it does not claim that multiuser hosting is configured.

## v4.1.0 confirmation fix

Enable Control/Automation now shows progress and any backend rejection directly inside its dialog. Background notifications were previously hidden by the native modal layer. Use Refresh campaign state if the displayed error indicates stale CampaignState. Permission failures require correcting the Five9 account and reconnecting. The update does not bypass either check.

## v4.1.0 Five9 permission parsing

The documented getMyPermissions response contains supervisorPermission records with `type` and boolean `value`. The previous parser treated these records as plain text, producing blank comma-separated entries and incorrectly blocking activation. v4.1.0 reads both fields, recognizes only explicitly granted permissions, and includes parsed permission details in diagnostics. A denied or missing permission is not elevated. Stop and reconnect after installing so the permissions are read again.

## v4.1 Insights

Open Insights to see evaluated measurements, threshold distance, condition/recovery progress, eligibility, conflicts, schedules and session trends. Follow INSIGHTS-GUIDE.md. Preserve your existing data/state.json when upgrading if you created rules or groups. All prior permission and dialog fixes are included.
