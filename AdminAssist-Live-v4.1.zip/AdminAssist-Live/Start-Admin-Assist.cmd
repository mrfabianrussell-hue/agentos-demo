@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Node.js 22 or later is required. Install Node.js and run this file again.
 pause
 exit /b 1
)
echo Open http://127.0.0.1:8787 after the server starts.
echo Keep this window open while using Admin Assist.
node server.mjs
pause
