# Admin Assist v4 — operating guide

## Find and act on many campaigns

Search by campaign name, select individual rows, select the visible page, or use **Select all matching campaigns**. Selections remain as you change filters and pages. **Review selected** lets you remove campaigns before acting.

Use reusable groups to maintain a shared target set. A rule can follow a group or keep a fixed list. **Add to rule** now selects several rules; the review includes other rules affected through shared groups. Group membership never expands just because a new campaign happens to match a name.

**More actions → Map selected to skill** changes the workspace’s queue/ready display mapping. It does not change routing in Five9. Saved views retain filters for the current profile on this browser.

## Start, Stop, and Force Stop

**Stop selected** remains normal stop. Active calls are allowed to finish. Individual and bulk commands run as background jobs under **Activity log → Campaign jobs**. Closing the browser leaves the backend running.

**More actions → Force stop selected**, or **Force stop** in campaign details, is manual only. Review all targets and type `DISCONNECT ACTIVE CALLS`. Force stop can disconnect active calls. Rules cannot issue it.

Job outcomes are distinct: Queued, Processing, Accepted, Verified, Pending, Skipped, Cancelled, or Needs attention. Accepted means Five9 acknowledged the request; Verified means its state feed confirmed the result. Cancel remaining affects commands not yet dispatched. It cannot undo commands already sent. Jobs are in-memory for this server session; audit history persists.

Review failed items before submitting them again. An uncertain prior request must be reconciled first. After two minutes, campaign details provide **Review unresolved request**: the backend refreshes actual state, removes the unresolved marker and recovery owner, and sets a 15-minute manual hold. A still-transitioning campaign may remain ineligible for normal commands.

## Build a rule

1. Name the rule and select its campaigns or reusable group. Jump buttons help navigate the editor.
2. Choose statistics or a date/time schedule. Source selection supports search, checkboxes, select all matching, and removable selected items.
3. For statistics, choose compatible metrics, comparisons, thresholds, and sustained time. Across sources, **Any** is the default; **All** is available. Measurements are compared individually, not summed.
4. Choose normal stop or start. Set a per-campaign cooldown and additional command retries (default 2, allowed 0–5).
5. Optionally enable automatic recovery on a metric-based stop rule. Recovery requires **every selected source** to meet the recovery threshold for the full recovery hold period.
6. Optionally restrict the rule and its recovery to operating hours, dates, weekdays, and exclusions. Hours are same-day: create separate rules for overnight segments. Restricting hours does not itself stop campaigns at the end; use a scheduled stop rule.
7. Review the plain-language summary and exact target list before saving.

Unavailable sources and metrics never become zero. If sources have no compatible metrics, choose a compatible set before saving. Missing campaign targets block the affected rule until repaired. Other configurations can still be saved when a previously configured target is missing.

A schedule-only rule does not require statistics sources. Weekly and one-time schedules use IANA timezones, with daylight-saving handling. Nonexistent local times are skipped; repeated local times use the first occurrence.

Scheduled batches must begin within five minutes of the scheduled time. An admitted batch may finish its original eligible targets for up to 60 minutes. Each command is checked again; manual overrides, operating hours and later opposing schedules can block it. Targets held at admission are excluded from that batch. Pause or leave automation to discard its remaining scheduled work. Missed runs are not automatically replayed.

## Monitoring, retries, and recovery

Conditions not met: the backend keeps monitoring. This does not consume retries. Hold time requires continuous valid readings; missing or stale data resets it. Freshness is limited to 60 seconds. Actual evaluation cadence depends on Five9 response time and queued work; the browser refreshes every five seconds and shows source age.

A definite HTTP 429 rejection can be retried with backoff. Before every attempt, the backend refreshes campaign state and rechecks mode, cancellation, rule conditions, schedules and overrides. Authentication, permission faults and uncertain transport outcomes are not blindly retried. Exhausted or uncertain automation commands latch a per-campaign rule error rather than restarting an infinite retry cycle. Review **Automations → Review rule errors** and the campaign’s state before choosing **Recheck eligibility**.

Stop conditions take precedence over automatic starts. An unavailable protective stop source also blocks automatic starts for its campaigns. A normal start rule cannot take over campaigns owned by another rule’s recovery. Scheduled closing rules block recovery after closing, and later scheduled actions supersede earlier admitted scheduled work. Distinct stop and recovery thresholds, plus a recovery hold, help avoid repeated switching.

Recovery only restarts campaigns this rule stopped. Manual control in this app clears that ownership. Direct changes in Five9 by other operators may not be attributable; coordinate control or disable recovery when necessary.

## Understand status

**Read-only**: collect data and configure rules; no campaign writes.

**Live control**: reviewed manual commands allowed; automatic execution disabled.

**Live automation**: enabled rules may execute when global evaluation is resumed.

Rule enabled, evaluation resumed, and execution authorized are separate states. Pausing automation leaves campaigns in their current state. Read-only also leaves running campaigns running. An already-dispatched Five9 request cannot be withdrawn by changing mode.

Rule cards explain measurements, data age, current evaluation, last action, per-campaign blocks and cooldowns. Campaign details list all associated rules, recovery ownership and manual holds. Read-only decision preview uses a copy of timers and does not advance live runtime.

**Degraded** means at least one statistics feed is unavailable. Feed health shows the affected source, error, age, and retry. Empty update responses cause a full snapshot; they do not mark old data fresh. Each feed initializes independently. Transient failures use backoff capped at 60 seconds; access failures need correction and reconnect. CampaignState freshness gates all commands; other feed failures block dependent rules.

## Preserve and move settings

Connections provides **Export configuration**, **Import configuration**, and **Download diagnostics**. Exports omit credentials. Imports replace rules/groups for the connected profile, disable imported rules, and pause evaluation; targets and sources must validate. Exports are primarily for backups of the same domain/account profile, not automatic cross-domain mapping.

Diagnostics omit credentials and account identity, but may include service errors and column names. Review before sharing. Saved views are browser-local and are not included in configuration exports.

Failed saves retain an explicit unsaved draft with Retry and Discard. Unrelated saves preserve existing timers. Changed rules and changed group dependencies reset their own runtime.

## Validation and boundaries

The package includes automated parser, transport, HTTP, bulk execution, scheduling, recovery, cancellation and retry checks. Browser checks exercised 660 campaign fixtures, source filtering, rule review/save, failed saves, force-stop acknowledgement, and schedule-only creation.

The supplied Five9 manuals informed the adapter. Your actual domain still needs the live verification described in `LIVE-VERIFICATION.md`. This remains a single-operator local backend, with memory-only Five9 credentials. Hosted demonstration content is separate. No Azure multiuser deployment is included.
