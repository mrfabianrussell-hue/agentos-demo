# v4 validation record

- 52 Node automated tests passed (parser, SOAP fixtures, HTTP security boundary, feed recovery, three-campaign background job, force-stop acknowledgement, per-target cooldowns, multi-source recovery, date exclusions, schedules, bounded retry, cancellation and dispatch authorization).
- Browser workflows passed using Chromium and a 660-campaign/80-source fixture: campaign filtering and bulk selection, multi-source rule review/save, operating hours and recovery, manual force-stop confirmation, queued job display, zero-source schedule creation, duplicate cancellation, and unsaved-draft discard. No uncaught browser errors in these checks.
- Rules and Connections screenshots inspected for layout.
- A separate 660-target engine check verified independent action records and cooldown suppression.

These checks use fixtures, not your actual Five9 account. Follow LIVE-VERIFICATION.md before enabling unattended execution.

Run `npm test` from the package folder to repeat the Node tests. No dependency installation is needed for the application or included tests. Browser tooling used during development is not shipped or required to run the app.

## v4.0.1 confirmation-dialog fix

Browser regression verified that missing confirmation text is shown inline; a backend rejection remains visible inside the modal top layer; the button shows progress and becomes usable after rejection; campaign-state refresh works; surrounding whitespace is accepted; Enter submits the confirmation; successful enable closes the dialog and retains the global pause. The actual live-account rejection remains unknown until displayed or supplied in diagnostics.

## v4.0.2 source layout fix

Browser check verified 16-pixel checkboxes, adjacent left-aligned source labels and 40-row pagination. Source heading/help spacing corrected; v4.0.1 inline activation feedback is included.

## v4.0.3 permissions fix

All 55 included Node tests passed. Added cases for documented type/value records, true/false and 1/0 boolean flags, unknown/missing flags, and a mixed account that can start but cannot stop. The HTTP live fixture now uses the documented structured permissions. The broader CampaignManagement flag does not imply granular start or stop permission. Actual live credentials were not available.

## v4.1 Insights

62 automated tests passed, including new threshold-direction, eligibility consistency, continuity-gap, bounded shared history, conflict, recovery-blocker and event-deduplication tests. Existing sustained-timer fixtures now provide intervening observations, because observation gaps over 60 seconds intentionally reset hold timers. Targeted evaluator/Insights checks passed after adding named conflict reasons. Browser checks used a 660-campaign fixture and verified the monitoring-only banner, hold progress, search and expanded-detail preservation across a live refresh, pause explanation, editor navigation and no default source selection. Dashboard layout inspected. Real domain authentication and campaign actions were not performed.
