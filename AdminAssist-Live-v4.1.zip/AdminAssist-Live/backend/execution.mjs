// Dependencies are injected so retry and cancellation behavior can be exercised without Five9.
export async function executeWithRetry({refresh,eligible,dispatch,state,accepted,retries=2,onRetry=()=>{},wait=ms=>new Promise(r=>setTimeout(r,ms)),wanted,allowStopping=false}){
 for(let attempt=0;attempt<=retries;attempt++){
  await refresh(attempt>0);
  if(!eligible())return {outcome:'Skipped',reason:'Eligibility, execution mode, or cancellation changed'};
  const current=state();
  if(current.pending)return {outcome:'Pending',reason:'A prior request still requires verification'};
  if(current.state===wanted)return {outcome:'Verified',reason:'Already in desired state'};
  if(!['Running','Stopped',...(allowStopping?['Stopping']:[])].includes(current.state))return {outcome:'Skipped',reason:'Campaign is '+current.state};
  try{await dispatch();await accepted();return {outcome:'Accepted',reason:'Awaiting Five9 state verification',attempts:attempt+1}}
  catch(error){if(error.cancelled)return {outcome:'Skipped',reason:error.message};
   // Authentication, permission errors, SOAP faults and uncertain transport results are never blindly retried.
   if(!error.retryable||attempt===retries){error.attempts=attempt+1;throw error}
   onRetry(attempt+1,error);await wait(Math.min(30000,2000*2**attempt));
  }
 }
}
export function preservedRuntime(oldRules,newRules,oldGroups,newGroups,runtime){const result={};for(const r of newRules){const old=oldRules.find(x=>x.id===r.id);const groupChanged=r.targetMode==='group'&&JSON.stringify(oldGroups.find(g=>g.id===r.groupId)?.members)!==JSON.stringify(newGroups.find(g=>g.id===r.groupId)?.members);if(old&&JSON.stringify(old)===JSON.stringify(r)&&!groupChanged&&runtime[r.id])result[r.id]=runtime[r.id]}return result}
