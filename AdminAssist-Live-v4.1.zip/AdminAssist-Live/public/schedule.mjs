const formatters=new Map();
function parts(t,tz){let f=formatters.get(tz);if(!f){f=new Intl.DateTimeFormat('en-CA',{timeZone:tz,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});formatters.set(tz,f)}return Object.fromEntries(f.formatToParts(new Date(t)).filter(p=>p.type!=='literal').map(p=>[p.type,p.value]))}
function localDate(t,tz){const p=parts(t,tz);return `${p.year}-${p.month}-${p.day}`}
export function localInstant(date,time,tz){
 if(!/^\d{4}-\d{2}-\d{2}$/.test(date||'')||!/^\d{2}:\d{2}$/.test(time||''))return null;
 const [y,m,d]=date.split('-').map(Number),[h,min]=time.split(':').map(Number);if(h>23||min>59)return null;const wall=Date.UTC(y,m-1,d,h,min);let offsets=new Set();
 try{for(const delta of [-36,0,36]){const t=wall+delta*3600000,p=parts(t,tz);offsets.add(Date.UTC(+p.year,+p.month-1,+p.day,+p.hour,+p.minute,+p.second)-t)}const candidates=[...offsets].map(o=>wall-o).filter(t=>{const p=parts(t,tz);return `${p.year}-${p.month}-${p.day}`===date&&`${p.hour}:${p.minute}`===time});return candidates.length?Math.min(...candidates):null}catch{return null}
}
function allowed(s,date){if((s.excludedDates||[]).includes(date))return false;if(s.kind==='once')return true;const day=new Date(date+'T12:00:00Z').getUTCDay();return (!s.startDate||date>=s.startDate)&&(!s.endDate||date<=s.endDate)&&(s.kind==='once'||(s.days||[]).includes(day))}
export function scheduleDue(s,now,lastOccurrence){
 if(!s?.zone||!s.time)return {status:'Blocked',reason:'Schedule is incomplete'};
 let date;try{date=s.kind==='once'?s.date:localDate(now,s.zone)}catch{return {status:'Blocked',reason:'Invalid time zone'}}
 if(!date||!allowed(s,date))return {status:'Scheduled',reason:'Outside the selected days or dates'};
 const due=localInstant(date,s.time,s.zone);if(due===null)return {status:'Skipped',reason:'This local time does not exist in the selected time zone'};
 const occurrence=`${date}T${s.time}@${s.zone}`;
 if(lastOccurrence===occurrence)return {status:'Completed',reason:'This scheduled occurrence was already applied',due,occurrence};
 if(now<due)return {status:'Scheduled',reason:'Waiting for the scheduled time',due,occurrence};
 if(now-due>=300000)return {status:s.kind==='once'?'Missed':'Scheduled',reason:'Past the 5-minute execution window; no late action',due,occurrence};
 return {status:'Ready',reason:'Scheduled time reached (within the 5-minute execution window)',due,occurrence};
}
export function nextRun(s,now){if(!s?.zone||!s.time)return null;if(s.kind==='once'){if(!allowed(s,s.date))return null;const t=localInstant(s.date,s.time,s.zone);return t!==null&&t>=now?t:null}let start;try{start=localDate(now,s.zone)}catch{return null}const base=Date.parse(start+'T12:00:00Z');for(let i=0;i<370;i++){const date=new Date(base+i*86400000).toISOString().slice(0,10);if(!allowed(s,date))continue;const t=localInstant(date,s.time,s.zone);if(t!==null&&t>=now)return t}return null}
export function latestRun(s,now){if(!s?.zone||!s.time)return null;if(s.kind==='once'){if(!allowed(s,s.date))return null;const t=localInstant(s.date,s.time,s.zone);return t!==null&&t<=now?t:null}let start;try{start=localDate(now,s.zone)}catch{return null}const base=Date.parse(start+'T12:00:00Z');for(let i=0;i<8;i++){const date=new Date(base-i*86400000).toISOString().slice(0,10);if(!allowed(s,date))continue;const t=localInstant(date,s.time,s.zone);if(t!==null&&t<=now)return t}return null}

export function withinWindow(w,now){if(!w?.enabled)return true;try{const date=localDate(now,w.zone),p=parts(now,w.zone),time=p.hour+':'+p.minute,day=new Date(date+'T12:00:00Z').getUTCDay();return !(w.excludedDates||[]).includes(date)&&(!w.startDate||date>=w.startDate)&&(!w.endDate||date<=w.endDate)&&(w.days||[]).includes(day)&&time>=w.start&&time<w.end}catch{return false}}
