export function resolveTargets(rule,domain){const ids=rule.targetMode==='group'?(domain.groups||[]).find(g=>g.id===rule.groupId)?.members||[]:rule.targets||[];const valid=new Set(domain.campaigns.map(c=>c.id));return [...new Set(ids)].filter(id=>valid.has(id))}
export function mergeIds(existing,added){return [...new Set([...existing,...added])]}
export function changeSummary(before,after){const a=new Set(before),b=new Set(after);return {added:[...b].filter(id=>!a.has(id)),removed:[...a].filter(id=>!b.has(id))}}
export function linkedRules(domain,id){return domain.rules.filter(r=>r.targetMode==='group'&&r.groupId===id)}

export function conflicts(rule,domain){const targets=new Set(resolveTargets(rule,domain));return domain.rules.filter(other=>other.id!==rule.id&&other.enabled&&other.action!==rule.action).map(other=>({id:other.id,name:other.name,action:other.action,count:resolveTargets(other,domain).filter(id=>targets.has(id)).length})).filter(c=>c.count);}
