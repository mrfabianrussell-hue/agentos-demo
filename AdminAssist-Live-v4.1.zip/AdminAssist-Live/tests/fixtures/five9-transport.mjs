// Test process preload only. No production server imports this module.
import fs from 'node:fs';
const realFetch=globalThis.fetch;let states=['RUNNING','RUNNING','RUNNING'];
const wrap=(method,body='')=>`<Envelope><Body><${method}Response>${body}</${method}Response></Body></Envelope>`;
const data=vs=>vs.map(v=>`<data>${v}</data>`).join('');
globalThis.fetch=async(url,options)=>{
 if(!String(url).startsWith('https://api.five9.com/wssupervisor/'))return realFetch(url,options);
 const method=options.body.match(/<ser:(\w+)>/)[1];let body='';
 if(method==='getMyPermissions')body='<return><type>CampaignManagementStart</type><value>true</value></return><return><type>CampaignManagementStop</type><value>true</value></return>';
 if(method==='getStatistics'){const type=options.body.match(/<statisticType>(.*?)</)[1];const columns=type==='CampaignState'?['Campaign Name','State','Type']:type==='ACDStatus'?['Skill Name','Calls In Queue','Agents Ready For Calls','Current Longest Queue Time']:['Campaign Name'];const rows=type==='CampaignState'?states.map((state,i)=>['Fixture '+i,state,'OUTBOUND']):type==='ACDStatus'?[['Inbound Fixture','8','10','1000']]:[['Fixture 0']];body=`<return><columns><values>${data(columns)}</values></columns>${rows.map(v=>`<rows><values>${data(v)}</values></rows>`).join('')}<timestamp>${Date.now()}</timestamp></return>`}
 // No return represents the original live error; adapter must independently re-snapshot.
 if(['startCampaign','stopCampaign','forceStopCampaign'].includes(method)){const name=options.body.match(/<campaignName>(.*?)</)[1];states[+name.split(' ')[1]]=method==='startCampaign'?'RUNNING':'NOT_RUNNING';fs.appendFileSync(process.env.AA_TEST_COMMANDS,method+' '+name+'\n')}
 return new Response(wrap(method,body),{status:200});
};
