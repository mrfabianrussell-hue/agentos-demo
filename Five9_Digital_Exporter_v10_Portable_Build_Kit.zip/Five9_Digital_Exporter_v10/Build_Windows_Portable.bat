@echo off
setlocal
cd /d "%~dp0"
echo Building portable Windows distribution (requires Python on BUILD computer only)...
py -m pip install --upgrade pip
if errorlevel 1 goto fail
py -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto fail
set "PLAYWRIGHT_BROWSERS_PATH=%CD%\browser_download"
py -m playwright install chromium
if errorlevel 1 goto fail
py -m PyInstaller --noconfirm --clean --onedir --windowed --name Five9Exporter --collect-all playwright app.py
if errorlevel 1 goto fail
if not exist "dist\Five9Exporter\browsers" mkdir "dist\Five9Exporter\browsers"
xcopy /E /I /Y "browser_download\*" "dist\Five9Exporter\browsers\" >nul
if errorlevel 1 goto fail
echo.
echo DONE: dist\Five9Exporter\Five9Exporter.exe
echo Copy the ENTIRE dist\Five9Exporter folder to the other Windows computer.
echo Do not copy only the EXE; browser components are required.
pause
exit /b 0
:fail
echo BUILD FAILED. Review errors above.
pause
exit /b 1
