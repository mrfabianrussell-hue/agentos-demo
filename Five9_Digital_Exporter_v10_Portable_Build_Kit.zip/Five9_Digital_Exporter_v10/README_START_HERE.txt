Five9 Digital Assistances Exporter v10 — Portable Windows BUILD PACKAGE

IMPORTANT: This ZIP contains source code plus a Windows build script. It does NOT
contain a compiled Windows EXE. Build once on a Windows PC with Python installed;
the resulting folder runs on other Windows PCs without Python.

BUILD COMPUTER (Windows, with Python):
1. Extract ZIP to a writable local folder.
2. Double-click Build_Windows_Portable.bat. Internet access is needed to download
   Python packages and the Playwright Chromium browser on the BUILD computer.
3. When successful, open dist\Five9Exporter\.
4. Double-click Five9Exporter.exe to test.
5. Copy the WHOLE dist\Five9Exporter folder to the target PC (USB/network share
   if company policy allows). Python is not needed on the target PC.

USE:
1. Launch Five9Exporter.exe.
2. Click Open Five9 Sign-in and sign in normally in the opened browser.
3. Navigate to Digital > Assistances.
4. Click Auto-scroll List, or manually scroll to load all records.
5. Check the captured count and click Export Captured.
6. Compare the workbook record count with Five9. Capture completeness cannot
   be guaranteed by scrolling alone. Never treat a partial export as complete.

SECURITY:
- Uses an isolated temporary browser context. Credentials are entered only
  on Five9's website, not into the exporter UI.
- Captures read-only assistance API responses from that browser context.
- Saves an XLSX and a raw JSON copy containing potentially sensitive response
  content to the chosen export folder. Protect or delete these files as needed.
- No browser extension, token copying, or OAuth client credentials required.
- Do not distribute outside your organization's approved users.
- Unsigned EXEs and bundled Chromium may be blocked by corporate endpoint policy.
- This browser-assisted method is not a Five9-supported API authentication flow.

KNOWN LIMITATION:
Auto-scroll is best effort; Five9 UI layout may change. Manual scrolling,
which worked in v9, remains supported. This is a test build and has NOT been
validated on a Windows workstation here.
