"""Browser-assisted Five9 exporter: captures API responses from the user's own Admin Console session.
No passwords, cookies or tokens are read or persisted by this application.
"""
import json, os, queue, threading, time, webbrowser, sys
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from urllib.parse import urlsplit, parse_qs
import extractor

# Use bundled Playwright browser in a packaged Windows distribution.
if getattr(sys, 'frozen', False):
    os.environ['PLAYWRIGHT_BROWSERS_PATH'] = str(Path(sys.executable).resolve().parent / 'browsers')
ADMIN_URL='https://admin.us.five9.net/digital-assistances'
API_HOST='api.prod.us.five9.net'
class App(tk.Tk):
    def __init__(self):
        super().__init__(); self.title('Five9 Assistances Exporter | v10 Portable Test');self.geometry('790x590')
        self.q=queue.Queue();self.pages={};self.browser_running=False;self.stop_event=threading.Event();self.scroll_event=threading.Event();self.pages_lock=threading.Lock()
        self.domain=tk.StringVar(value='109388');self.output=tk.StringVar(value=str(Path.home()/'Documents'/'Five9 Exports'))
        self.status=tk.StringVar(value='Ready. Open the Five9 browser and sign in with your provisioned account.')
        frm=ttk.Frame(self,padding=18);frm.pack(fill='both',expand=True)
        ttk.Label(frm,text='Five9 Assistances Exporter',font=('Segoe UI',19,'bold')).pack(anchor='w')
        ttk.Label(frm,text='Browser-assisted test • Read-only • No credentials or access tokens copied',foreground='#225d79').pack(anchor='w',pady=(2,12))
        row=ttk.Frame(frm);row.pack(fill='x',pady=4)
        ttk.Label(row,text='Domain ID',width=15).pack(side='left');ttk.Entry(row,textvariable=self.domain,width=17).pack(side='left')
        row2=ttk.Frame(frm);row2.pack(fill='x',pady=4)
        ttk.Label(row2,text='Export folder',width=15).pack(side='left');ttk.Entry(row2,textvariable=self.output).pack(side='left',fill='x',expand=True)
        ttk.Button(row2,text='Browse',command=self.browse).pack(side='left',padx=6)
        ttk.Label(frm,text='1. Open Five9 and sign in.  2. Open Digital → Assistances.  3. Click Auto-scroll (or scroll manually).  4. Export.',wraplength=740).pack(anchor='w',pady=(12,10))
        btn=ttk.Frame(frm);btn.pack(fill='x')
        self.open_btn=ttk.Button(btn,text='1  Open Five9 Sign-in',command=self.open_browser);self.open_btn.pack(side='left',padx=(0,10))
        self.scroll_btn=ttk.Button(btn,text='2  Auto-scroll List',command=self.request_scroll,state='disabled');self.scroll_btn.pack(side='left',padx=(0,10))
        self.export_btn=ttk.Button(btn,text='3  Export Captured',command=self.export,state='disabled');self.export_btn.pack(side='left')
        ttk.Button(btn,text='Open Export Folder',command=self.open_folder).pack(side='right')
        ttk.Label(frm,textvariable=self.status,wraplength=740).pack(anchor='w',pady=(16,7))
        self.log=tk.Text(frm,height=17,wrap='word',font=('Consolas',9),state='disabled');self.log.pack(fill='both',expand=True)
        ttk.Label(frm,text='IMPORTANT: The Admin Console may load only some records. This test never labels a partial capture as complete. Do not close the browser until export finishes.',wraplength=740,foreground='#885000').pack(anchor='w',pady=(9,0))
        self.after(150,self.poll)
    def browse(self):
        p=filedialog.askdirectory(initialdir=self.output.get());
        if p:self.output.set(p)
    def line(self,s):
        self.log.configure(state='normal');self.log.insert('end',s+'\n');self.log.see('end');self.log.configure(state='disabled')
    def poll(self):
        try:
            while True:
                kind,val=self.q.get_nowait()
                if kind=='log':self.line(val)
                if kind=='status':self.status.set(val)
                if kind=='ready':self.export_btn.configure(state='normal')
                if kind=='browser_ready':self.scroll_btn.configure(state='normal')
                if kind=='closed':self.browser_running=False;self.open_btn.configure(state='normal');self.scroll_btn.configure(state='disabled')
        except queue.Empty:pass
        self.after(150,self.poll)
    def open_browser(self):
        if self.browser_running:return
        domain=self.domain.get().strip()
        if not domain.isdecimal():messagebox.showerror('Domain','Domain ID must be numeric.');return
        self.pages={};self.scroll_event.clear();self.browser_running=True;self.open_btn.configure(state='disabled');self.export_btn.configure(state='disabled');self.scroll_btn.configure(state='disabled')
        threading.Thread(target=self.browser_worker,args=(domain,),daemon=True).start()
    def browser_worker(self,domain):
        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as p:
                browser=p.chromium.launch(headless=False)
                context=browser.new_context(accept_downloads=False)
                page=context.new_page()
                def received(response):
                    try:
                        url=urlsplit(response.url)
                        if url.hostname != API_HOST or response.request.method!='GET':return
                        if url.path != f'/digital-config-svc/v1/domains/{domain}/assistances':return
                        if response.status != 200:
                            self.q.put(('log',f'Assistances response: HTTP {response.status} (no response body stored).'));return
                        payload=response.json()
                        items=extractor.payload_items(payload)
                        if not isinstance(items,list):return
                        # Store assistance response bodies only; never store request headers/cookies/tokens.
                        ids=tuple(str(x.get('assistanceId','')) for x in items if isinstance(x,dict))
                        cursor=parse_qs(url.query).get('pageCursor',[''])[0]
                        key=cursor or ('initial:'+','.join(ids[:2]))
                        with self.pages_lock:
                            self.pages[key]=payload
                            total=len({str(x.get('assistanceId')) for d in self.pages.values() for x in extractor.payload_items(d) if isinstance(x,dict)})
                        next_exists=bool((payload.get('paging') or {}).get('next')) if isinstance(payload,dict) else False
                        self.q.put(('log',f'Captured page: {len(items)} items; {total} unique total. Server next cursor: {"yes" if next_exists else "no"}.'))
                        self.q.put(('ready',None))
                    except Exception as exc:
                        self.q.put(('log',f'Could not parse response ({type(exc).__name__}).'))
                page.on('response',received)
                self.q.put(('status','Browser opened. Sign in, then visit Digital → Assistances and navigate all pages.'))
                self.q.put(('log','A separate temporary browser is open. Sign in directly on Five9; this app does not see your password.'))
                page.goto(ADMIN_URL,wait_until='domcontentloaded',timeout=60000)
                self.q.put(('browser_ready',None))
                while browser.is_connected():
                    try:
                        if self.scroll_event.is_set():
                            self.scroll_event.clear()
                            self.auto_scroll(page)
                        page.wait_for_timeout(400)
                    except Exception as exc:
                        self.q.put(('log',f'Browser navigation ended: {type(exc).__name__}'))
                        break
                self.q.put(('log','Browser closed.'))
        except Exception as exc:
            self.q.put(('log',f'Browser error: {type(exc).__name__}: {str(exc)[:240]}'))
            self.q.put(('log','If browser executable is missing, run Install_Dependencies.bat.'))
        finally:self.q.put(('closed',None))
    def request_scroll(self):
        self.q.put(('log','Auto-scroll requested. Keep the Five9 Assistances list visible.'))
        self.scroll_event.set()
    def auto_scroll(self,page):
        # Scroll the tallest visible scrollable region. This is best effort only;
        # Five9's virtualized list may need manual scrolling as a fallback.
        self.q.put(('log','Auto-scroll started; the browser will move through the list.'))
        stable=0; previous=-1
        for step in range(120):
            if not page.url.startswith('https://admin.us.five9.net/'):
                self.q.put(('log','Auto-scroll stopped: not on the Five9 Admin Console.'));return
            try:
                state=page.evaluate('''() => {
                  const candidates=[document.scrollingElement,...document.querySelectorAll('*')]
                    .filter(e=>e && e.scrollHeight>e.clientHeight+80 && e.clientHeight>130)
                    .filter(e=>{const st=getComputedStyle(e);return e===document.scrollingElement || ['auto','scroll'].includes(st.overflowY)});
                  const el=candidates.sort((a,b)=>(b.clientHeight*b.scrollHeight)-(a.clientHeight*a.scrollHeight))[0];
                  if(!el)return null;
                  el.scrollTop=Math.min(el.scrollHeight,el.scrollTop+Math.max(220,el.clientHeight*.8));
                  return {top:Math.round(el.scrollTop),height:el.scrollHeight,client:el.clientHeight};
                }''')
                page.wait_for_timeout(350)
                if not state: self.q.put(('log','No scrollable list found. Scroll manually.'));return
                pos=state['top']; stable=stable+1 if pos==previous else 0;previous=pos
                if step%15==0:self.q.put(('log',f'Auto-scroll progress: step {step+1}; position {pos}.'))
                if stable>=7:break
            except Exception as exc:
                self.q.put(('log',f'Auto-scroll interrupted: {type(exc).__name__}. Scroll manually.'));return
        self.q.put(('log','Auto-scroll finished. Check captured count; scroll manually if needed.'))
    def export(self):
        with self.pages_lock: pages=list(self.pages.values())
        if not pages:messagebox.showwarning('No data','No assistance API responses captured. Open Five9 and visit Digital → Assistances.');return
        # Detect gaps by following server next pointers among captured page requests.
        next_count=sum(bool((x.get('paging') or {}).get('next')) for x in pages if isinstance(x,dict))
        has_terminal=any(not (x.get('paging') or {}).get('next') for x in pages if isinstance(x,dict))
        complete=has_terminal and (len(pages)>next_count)
        if not complete:
            ok=messagebox.askyesno('Possibly incomplete',f'Captured {len(pages)} response page(s). No reliable evidence that every page was captured.\n\nExport a PARTIAL workbook for testing?')
            if not ok:return
        try:
            out=Path(self.output.get()).expanduser();out.mkdir(parents=True,exist_ok=True)
            extractor.export(pages,out)
            unique=len({str(x.get('assistanceId')) for d in pages for x in extractor.payload_items(d) if isinstance(x,dict)})
            self.line(f'Exported {unique} unique Assistances from {len(pages)} captured response(s).')
            if not complete:self.line('WARNING: Capture may be incomplete; verify all UI pages were visited.')
            self.status.set(f'Export saved to {out}. '+('Verify count against Five9.' if complete else 'PARTIAL/UNVERIFIED capture.'))
            messagebox.showinfo('Export saved',f'{unique} unique Assistances exported.\nFolder: {out}\n\nVerify count against Five9. Browser UI may not expose all pages.')
        except Exception as exc:messagebox.showerror('Export failed',str(exc)[:350])
    def open_folder(self):
        p=Path(self.output.get()).expanduser();p.mkdir(parents=True,exist_ok=True)
        if os.name=='nt':os.startfile(str(p))
        else:webbrowser.open(p.as_uri())
if __name__=='__main__':App().mainloop()
