#!/usr/bin/env python3
"""Read-only Five9 Digital Assistances export. No API write operations."""
import argparse, getpass, html, json, os, re, sys, time
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin, urlparse, parse_qs

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo

class HTMLText(HTMLParser):
    def __init__(self): super().__init__(convert_charrefs=True); self.parts=[]
    def handle_starttag(self, tag, attrs):
        if tag.lower() in ('p','div','li','br','tr','h1','h2','h3'): self.parts.append('\n')
    def handle_data(self, data): self.parts.append(data)
    def get(self):
        value=''.join(self.parts).replace('\xa0',' ')
        return re.sub(r'\n{3,}', '\n\n', '\n'.join(s.strip() for s in value.splitlines())).strip()

def plain(value):
    parser=HTMLText(); parser.feed(value or ''); return parser.get()

def safe_cell(value):
    if value is None: return ''
    if not isinstance(value,str): value=json.dumps(value,ensure_ascii=False) if isinstance(value,(list,dict)) else str(value)
    # Avoid formula injection when opening exports in Excel.
    if value.lstrip().startswith(('=','+','-','@')): value="'"+value
    return value[:32767]

def payload_items(payload):
    if isinstance(payload,list): return payload
    if not isinstance(payload,dict): raise ValueError('Expected JSON object or array')
    for key in ('assistances','items','results','data'):
        obj=payload.get(key)
        if isinstance(obj,list): return obj
        if isinstance(obj,dict):
            for nested in ('assistances','items','results'):
                if isinstance(obj.get(nested),list): return obj[nested]
    raise ValueError('No assistance array found in response')

def read_input(path):
    p=Path(path)
    if p.is_dir():
        files=sorted(p.glob('*.json'))
        if not files: raise ValueError('No .json files in input directory')
        return [json.loads(f.read_text(encoding='utf-8-sig')) for f in files]
    return [json.loads(p.read_text(encoding='utf-8-sig'))]

def _safe_diagnostic(value, token=''):
    """Conservative redaction for server-generated diagnostics; no raw token/body logs."""
    value = str(value or '')
    if token: value = value.replace(token, '[REDACTED TOKEN]')
    value = re.sub(r'(?i)bearer\s+[^\s,;]+', 'Bearer [REDACTED]', value)
    value = re.sub(r'\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]*)?\b', '[REDACTED JWT]', value)
    value = re.sub(r'(?i)(client_secret|access_token|refresh_token|password|authorization|client_id)\s*[:=]\s*[^\s,;]+', r'\1=[REDACTED]', value)
    value = re.sub(r'https?://[^\s,;]+', '[URL REDACTED]', value)
    value = re.sub(r'\b[^\s@]+@[^\s@]+\.[^\s@]+\b', '[EMAIL REDACTED]', value)
    return re.sub(r'[\r\n\t]+', ' ', value)[:250]

def token_diagnostics(token):
    """Report only non-sensitive JWT metadata; never print claims, token, subject or IDs."""
    import base64
    parts = token.split('.')
    if len(parts) != 3:
        return ['Access token format: opaque/non-JWT (claims cannot be inspected locally).']
    try:
        raw = base64.urlsafe_b64decode(parts[1] + '=' * (-len(parts[1]) % 4))
        claims = json.loads(raw)
        if not isinstance(claims, dict): raise ValueError('not a JWT object')
    except (ValueError, UnicodeError, TypeError):
        return ['Access token format: JWT-like; claims could not be decoded.']
    result = ['Access token format: JWT (decoded locally; identifying claims withheld).']
    # Only presence flags, never arbitrary claims or values that could identify users.
    for field in ('aud','scope','scp','iss','exp','nbf'):
        result.append(f'JWT {field}: {"present" if field in claims else "absent"}')
    scp = claims.get('scp')
    if isinstance(scp, str):
        scopes = scp.split()
    elif isinstance(scp, list):
        scopes = [x for x in scp if isinstance(x, str)]
    else:
        scopes = []
    result.append(f'JWT scp entry count: {len(scopes)}')
    # Scopes are permission identifiers, not credentials. Restrict to simple
    # identifier syntax; suppress unexpected content rather than logging it.
    for idx, value in enumerate(scopes[:30], 1):
        if re.fullmatch(r'[A-Za-z0-9_.:/-]{1,100}', value):
            result.append(f'JWT scp[{idx}]: {value}')
        else:
            result.append(f'JWT scp[{idx}]: [nonstandard value withheld]')
    if len(scopes) > 30:
        result.append(f'JWT scp: {len(scopes)-30} additional entries withheld')
    try:
        exp = claims.get('exp')
        if isinstance(exp, (int, float)):
            seconds = int(exp - time.time())
            result.append('JWT expiry status: ' + ('expired' if seconds <= 0 else f'valid for approximately {seconds // 60} more minutes'))
    except (OverflowError, ValueError): pass
    return result

def safe_api_error(response, token=''):
    """Show server-returned diagnostics and structural facts, without dumping secrets."""
    status = response.status_code
    lines = [f'Assistances API returned HTTP {status}.',
             f'HTTP reason: {_safe_diagnostic(response.reason, token)}',
             f'Response content type: {_safe_diagnostic(response.headers.get("content-type", "not provided"), token)}',
             f'Response body bytes: {len(response.content)}']
    for key in ('x-request-id', 'x-correlation-id', 'x-amzn-requestid', 'x-amzn-trace-id', 'traceparent', 'request-id', 'x-trace-id'):
        val = response.headers.get(key, '')
        if val and re.fullmatch(r'[A-Za-z0-9_.:/=;-]{1,180}', val):
            lines.append(f'{key}: {val}')
    challenge = response.headers.get('WWW-Authenticate')
    if challenge:
        # Only report standardized Bearer challenge error / scope existence;
        # never include realm, URI, descriptions or arbitrary parameters.
        import re as _re
        scheme = challenge.split(' ',1)[0]
        lines.append('WWW-Authenticate scheme: ' + (_safe_diagnostic(scheme) if scheme.lower() in ('bearer','basic') else 'other'))
        for key in ('error','error_description','scope'):
            match = _re.search(r'(?i)(?:^|[,\s])'+key+r'\s*=\s*(?:"([^"]*)"|([^,\s]+))',challenge)
            if match:
                if key == 'error': lines.append('WWW-Authenticate error: ' + _safe_diagnostic(match.group(1) or match.group(2),token))
                else: lines.append(f'WWW-Authenticate {key}: present (value withheld)')
    else:
        lines.append('WWW-Authenticate: not provided')
    try: payload = response.json()
    except (ValueError, TypeError): payload = None
    if isinstance(payload, dict):
        lines.append('JSON response keys: ' + ', '.join(sorted(str(k)[:45] for k in payload.keys())[:20]))
        recognized = False
        for field in ('error', 'errorCode', 'code', 'message', 'error_description', 'description', 'detail', 'status', 'title', 'type'):
            val = payload.get(field)
            if isinstance(val,(str,int,float)):
                lines.append(f'Server {field}: {_safe_diagnostic(val,token)}')
                recognized = True
        errors = payload.get('errors')
        if isinstance(errors, list):
            lines.append(f'Server errors array: {len(errors)} item(s)')
            for item in errors[:2]:
                if isinstance(item,dict):
                    for field in ('code','message','detail'):
                        if isinstance(item.get(field),(str,int,float)):
                            lines.append(f'Server errors.{field}: {_safe_diagnostic(item[field],token)}')
                            recognized = True
        # Five9 gateway errors can use a nested `fault` object rather than
        # top-level error/message fields. Walk only known error-shaped fields;
        # never dump raw JSON, arbitrary objects, or identifying values.
        fault = payload.get('fault')
        if isinstance(fault, dict):
            lines.append('Server fault: object')
            lines.append('Server fault keys: ' + ', '.join(sorted(str(k)[:45] for k in fault.keys())[:20]))
            for key in ('faultstring', 'faultcode', 'message', 'code', 'error', 'error_description', 'description', 'detail', 'status', 'title'):
                val = fault.get(key)
                if isinstance(val, (str, int, float)):
                    lines.append(f'Server fault.{key}: {_safe_diagnostic(val,token)}')
                    recognized = True
            details = fault.get('detail')
            if isinstance(details, dict):
                lines.append('Server fault.detail keys: ' + ', '.join(sorted(str(k)[:45] for k in details.keys())[:20]))
                for key in ('errorcode', 'errorCode', 'code', 'message', 'description', 'faultstring'):
                    val = details.get(key)
                    if isinstance(val, (str, int, float)):
                        lines.append(f'Server fault.detail.{key}: {_safe_diagnostic(val,token)}')
                        recognized = True
        elif fault is not None:
            lines.append('Server fault type: ' + type(fault).__name__ + ' (contents withheld)')
        if not recognized: lines.append('No recognized textual error details in JSON response.')
    elif isinstance(payload,list):
        lines.append(f'JSON response: array with {len(payload)} item(s); raw contents withheld.')
    else:
        if not response.content: lines.append('Response body: empty (Five9 supplied no explanation).')
        elif 'text/plain' in response.headers.get('content-type','').lower():
            lines.append('Server text: ' + _safe_diagnostic(response.text[:300],token))
        else: lines.append('Response body is non-JSON or unsupported; raw contents withheld.')
    lines.extend(token_diagnostics(token))
    lines.append('Interpretation: HTTP status is from Five9; any potential causes require confirmation by Five9 Support.')
    return '\n'.join(lines)

def api_fetch(domain, token, page_limit, timeout):
    """Follow the server-provided paging.next URL; never guess offsets or cursors."""
    import requests
    from urllib.parse import urlsplit
    host = 'https://api.prod.us.five9.net'
    root = f'/digital-config-svc/v1/domains/{domain}/assistances'
    next_url = f'{host}{root}?pageLimit={page_limit}'
    session = requests.Session()
    session.headers.update({'Authorization': f'Bearer {token}', 'Accept': 'application/json'})
    pages, visited = [], set()
    for page_number in range(1000):
        parsed = urlsplit(next_url)
        if parsed.scheme != 'https' or parsed.netloc != 'api.prod.us.five9.net' or parsed.path != root:
            raise RuntimeError('Unexpected pagination URL; stopped for safety')
        if next_url in visited:
            raise RuntimeError('Pagination cursor repeated; stopped to avoid duplicate retrieval')
        visited.add(next_url)
        response = session.get(next_url, timeout=timeout)
        if response.status_code in (401, 403):
            raise RuntimeError(safe_api_error(response, token))
        if not response.ok:
            raise RuntimeError(safe_api_error(response, token))
        data = response.json()
        items = payload_items(data)
        pages.append(data)
        print(f'Page {page_number + 1}: {len(items)} Assistances', flush=True)
        paging = data.get('paging') or {} if isinstance(data, dict) else {}
        continuation = paging.get('next') if isinstance(paging, dict) else None
        if not continuation:
            print('No next-page cursor returned; pagination complete.', flush=True)
            break
        next_url = urljoin(host + '/', continuation)
    else:
        raise RuntimeError('Pagination exceeded 1,000-page safety limit')
    return pages

def export(pages, outdir):
    outdir.mkdir(parents=True,exist_ok=True)
    records=[]; seen=set()
    for page in pages:
        for item in payload_items(page):
            if not isinstance(item,dict): continue
            key=item.get('assistanceId') or json.dumps(item,sort_keys=True)
            if key in seen: continue
            seen.add(key); records.append(item)
    if not records: raise ValueError('No assistance records found')
    wb=Workbook(); ws=wb.active; ws.title='Assistances'
    headers=['Assistance Name','Type','Response (Plain Text)','Response (HTML)','Associated Profiles','Profile IDs','Profile Count','In Use','Editable','Rich Text Email Enabled','Messaging Enabled','Labels','Buttons','Created On (UTC)','Assistance ID','Profile URIs','Additional Properties (JSON)']
    ws.append(headers)
    known={'assistanceId','name','enableRichTextEmailOnly','enableRichControlsMessaging','isEditable','inUse','associatedProfiles','response','labels','buttons','createdOn'}
    for a in records:
        profiles=a.get('associatedProfiles') or []
        if not isinstance(profiles,list): profiles=[]
        email=bool(a.get('enableRichTextEmailOnly')); msg=bool(a.get('enableRichControlsMessaging'))
        typ='Email + Messaging' if email and msg else 'Email' if email else 'Messaging' if msg else 'None/Unspecified'
        created=a.get('createdOn') or ''
        row=[a.get('name'),typ,plain(a.get('response')),a.get('response'),'; '.join(str(p.get('name')) for p in profiles if isinstance(p,dict) and p.get('name')), '; '.join(str(p.get('profileId')) for p in profiles if isinstance(p,dict) and p.get('profileId')),len(profiles),a.get('inUse'),a.get('isEditable'),a.get('enableRichTextEmailOnly'),a.get('enableRichControlsMessaging'),a.get('labels'),a.get('buttons'),created,a.get('assistanceId'),'; '.join(str(p.get('uri')) for p in profiles if isinstance(p,dict) and p.get('uri')),{k:v for k,v in a.items() if k not in known}]
        ws.append([safe_cell(v) for v in row])
    ws.freeze_panes='C2'; ws.auto_filter.ref=ws.dimensions
    widths=[49,22,85,65,53,48,15,12,12,22,20,28,35,27,42,60,55]
    for i,w in enumerate(widths,1): ws.column_dimensions[get_column_letter(i)].width=w
    for cell in ws[1]: cell.fill=PatternFill('solid',fgColor='16324F'); cell.font=Font(name='Aptos',size=11,bold=True,color='FFFFFF'); cell.alignment=Alignment(vertical='center',wrap_text=True)
    ws.row_dimensions[1].height=32
    for r in range(2,ws.max_row+1):
        ws.row_dimensions[r].height=55
        for c in ws[r]:
            c.alignment=Alignment(vertical='top',wrap_text=True)
            c.font=Font(name='Aptos',size=10,color='18324A')
            if r%2==0: c.fill=PatternFill('solid',fgColor='F1F6FA')
    xlsx=outdir/'Five9_Digital_Assistances.xlsx'; wb.save(xlsx)
    raw=outdir/'Five9_Assistances_Raw.json'; raw.write_text(json.dumps({'retrievedAtUtc':datetime.now(timezone.utc).isoformat(),'pageCount':len(pages),'recordCount':len(records),'pages':pages},ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'Exported {len(records)} unique Assistances across {len(pages)} page(s).\n{xlsx}\n{raw}')

def main():
    p=argparse.ArgumentParser(description='Five9 Digital Assistances read-only one-sheet exporter')
    group=p.add_mutually_exclusive_group(required=True)
    group.add_argument('--input',help='Saved Five9 API response JSON file or folder of paginated responses')
    group.add_argument('--domain',help='Five9 domain ID for direct API retrieval (requires Bearer token)')
    p.add_argument('--output',default='output'); p.add_argument('--page-limit',type=int,default=100); p.add_argument('--timeout',type=int,default=30)
    args=p.parse_args()
    try:
        if args.input: pages=read_input(args.input)
        else:
            token=os.environ.get('FIVE9_BEARER_TOKEN') or getpass.getpass('Five9 API Bearer token (not stored): ').strip()
            if not token: raise ValueError('Missing Bearer token')
            pages=api_fetch(args.domain,token,args.page_limit,args.timeout)
        export(pages,Path(args.output))
    except Exception as e:
        print(f'ERROR: {e}',file=sys.stderr); sys.exit(1)

if __name__=='__main__': main()
