@echo off
cd /d "%~dp0"
py -3 -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto fail
py -3 -m PyInstaller --noconfirm --clean --onefile --windowed --name Five9DigitalExporter --collect-all openpyxl app.py
if errorlevel 1 goto fail
echo.
echo SUCCESS: dist\Five9DigitalExporter.exe
pause
exit /b 0
:fail
echo Build failed. See errors above.
pause
exit /b 1
