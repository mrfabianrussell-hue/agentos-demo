FIVE9 DIGITAL CONFIGURATION EXPORTER — V8 DIAGNOSTIC TEST

WHAT CHANGED
- Reads recognized fields inside Five9 JSON `fault` and `fault.detail` objects.
- Reports the `fault` field names, even when no readable message is supplied.
- Shows JWT `scp` permission identifiers (up to 30), but never the JWT itself.
- Retains HTTP response metadata and x-request-id diagnostics.
- No API writes. Client ID and Secret are not saved.

TO TEST
1. Extract the entire ZIP to a new folder.
2. Double-click Launch_Exporter.bat (run Install_Dependencies.bat if needed).
3. Enter your OAuth Client ID and Client Secret locally. Do not share them.
4. Keep the same token settings that succeeded in V7.
5. Click Connect & Export Assistances to Excel.
6. If it fails, click Copy Diagnostic Log. REVIEW THE LOG BEFORE SHARING.

SECURITY
JWT scp values are permission names and can reveal configuration details;
share with Five9 Support as appropriate. The tool never intentionally logs
access tokens, client credentials, or the complete JSON error response.

NOTE
This is a Python test package, not a precompiled Windows EXE. No live Five9
connection was available for validation; error parsing was tested locally.
