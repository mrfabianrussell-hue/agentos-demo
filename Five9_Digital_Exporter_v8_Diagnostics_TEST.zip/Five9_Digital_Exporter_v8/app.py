"""Read-only Five9 Digital Assistances exporter with OAuth client credentials."""
import json, os, queue, threading, webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from urllib.parse import urlsplit
import requests
import extractor

TOKEN_URL = 'https://api.prod.us.five9.net/oauth2/v1/token'
SETTINGS = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'Five9DigitalExporter' / 'settings-v8.json'

def load_settings():
    try: return json.loads(SETTINGS.read_text(encoding='utf-8'))
    except (OSError, ValueError): return {}

def get_access_token(client_id, client_secret, token_url, method, scope='', timeout=25):
    if not client_id.strip() or not client_secret: raise ValueError('Enter Client ID and Client Secret.')
    parsed=urlsplit(token_url)
    if parsed.scheme != 'https' or parsed.hostname != 'api.prod.us.five9.net' or parsed.path != '/oauth2/v1/token' or parsed.username or parsed.password or parsed.port:
        raise ValueError('Token URL must be the confirmed Five9 US OAuth endpoint.')
    data={'grant_type':'client_credentials'}
    if scope.strip(): data['scope']=scope.strip()
    headers={'Accept':'application/json','Content-Type':'application/x-www-form-urlencoded'}
    kwargs={'data':data,'headers':headers,'timeout':timeout,'allow_redirects':False}
    if method=='basic': kwargs['auth']=(client_id.strip(),client_secret)
    elif method=='body': data.update({'client_id':client_id.strip(),'client_secret':client_secret})
    else: raise ValueError('Unknown OAuth credential placement')
    try: response=requests.post(token_url,**kwargs)
    except requests.RequestException as e: raise RuntimeError(f'Could not reach Five9 OAuth endpoint ({type(e).__name__}).') from None
    if response.is_redirect: raise RuntimeError('OAuth endpoint redirected; stopped for safety.')
    if not response.ok:
        # Avoid printing token response body, which could include sensitive values.
        hint={400:'Request format, grant, or scope may be rejected.',401:'Client credentials or authentication method rejected.',403:'Client is not permitted to request a token.',404:'OAuth endpoint not found.',429:'Rate limited; wait before retrying.'}.get(response.status_code,'Check API client configuration and service availability.')
        raise RuntimeError(f'OAuth token request returned HTTP {response.status_code}. {hint}')
    try: payload=response.json()
    except ValueError: raise RuntimeError('OAuth endpoint did not return JSON.') from None
    token=payload.get('access_token') if isinstance(payload,dict) else None
    if not isinstance(token,str) or not token.strip(): raise RuntimeError('OAuth response did not include access_token.')
    return token.strip()

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Five9 Digital Configuration Exporter | v8 OAuth Fault Diagnostics')
        self.geometry('850x735'); self.minsize(750,650)
        settings=load_settings(); self.events=queue.Queue(); self.busy=False; self.last_xlsx=None
        self.domain=tk.StringVar(value=settings.get('domain','109388'))
        self.out=tk.StringVar(value=settings.get('output',str(Path.home()/'Documents'/'Five9 Exports')))
        self.client_id=tk.StringVar(); self.secret=tk.StringVar()
        self.token_url=tk.StringVar(value=TOKEN_URL)
        self.method=tk.StringVar(value=settings.get('method','basic'))
        self.scope=tk.StringVar(value=settings.get('scope',''))
        self.status=tk.StringVar(value='Ready. Enter your API client credentials, then select Connect & Export.')
        style=ttk.Style(self); style.theme_use('clam')
        style.configure('TLabel',font=('Segoe UI',10)); style.configure('TButton',font=('Segoe UI',10),padding=7)
        root=ttk.Frame(self,padding=22);root.pack(fill='both',expand=True)
        ttk.Label(root,text='Five9 Digital Configuration Exporter',font=('Segoe UI',19,'bold')).pack(anchor='w')
        ttk.Label(root,text='OAuth 2.0 • Read-only • All Assistances • One Excel worksheet').pack(anchor='w',pady=(3,5))
        ttk.Label(root,text='v8: inspects nested Five9 fault details and permission names (scp) for Support.',foreground='#175580').pack(anchor='w',pady=(0,12))
        grid=ttk.Frame(root);grid.pack(fill='x'); grid.columnconfigure(1,weight=1)
        def field(row,label,var,show=None):
            ttk.Label(grid,text=label).grid(row=row,column=0,sticky='w',pady=5)
            ttk.Entry(grid,textvariable=var,show=show).grid(row=row,column=1,sticky='ew',padx=(14,8),pady=5)
        field(0,'Five9 Domain ID',self.domain)
        field(1,'OAuth Token URL',self.token_url)
        field(2,'Client ID',self.client_id)
        field(3,'Client Secret',self.secret,'●')
        field(4,'Scope (optional)',self.scope)
        ttk.Label(grid,text='Credential placement').grid(row=5,column=0,sticky='w',pady=6)
        options=ttk.Frame(grid);options.grid(row=5,column=1,sticky='w',padx=(14,0))
        ttk.Radiobutton(options,text='HTTP Basic (test first)',variable=self.method,value='basic').pack(side='left',padx=(0,15))
        ttk.Radiobutton(options,text='Request body',variable=self.method,value='body').pack(side='left')
        field(6,'Export folder',self.out)
        ttk.Button(grid,text='Browse…',command=self.browse).grid(row=6,column=2)
        ttk.Label(root,text='Client credentials are used only for this session and are not saved. Do not share them or exported customer information.',wraplength=740,foreground='#72510a').pack(anchor='w',pady=(13,10))
        self.button=ttk.Button(root,text='Connect & Export Assistances to Excel',command=self.start)
        self.button.pack(fill='x',ipady=8)
        ttk.Label(root,textvariable=self.status,wraplength=740).pack(anchor='w',pady=(13,6))
        self.progress=ttk.Progressbar(root,mode='indeterminate');self.progress.pack(fill='x')
        self.log=tk.Text(root,height=15,state='disabled',font=('Consolas',9),wrap='word');self.log.pack(fill='both',expand=True,pady=(12,8))
        footer=ttk.Frame(root);footer.pack(fill='x')
        ttk.Button(footer,text='Copy Diagnostic Log',command=self.copy_log).pack(side='left',padx=(0,10))
        ttk.Button(footer,text='Open Export Folder',command=self.open_folder).pack(side='left')
        ttk.Button(footer,text='Open Excel',command=self.open_excel).pack(side='left',padx=10)
        ttk.Button(footer,text='Five9 Admin Console',command=lambda:webbrowser.open('https://admin.us.five9.net/digital-assistances')).pack(side='right')
        self.after(100,self.poll)
    def copy_log(self):
        content=self.log.get('1.0','end-1c')
        self.clipboard_clear(); self.clipboard_append(content)
        self.status.set('Diagnostic log copied. Review before sharing with Five9 Support.')
    def browse(self):
        folder=filedialog.askdirectory(initialdir=self.out.get());
        if folder:self.out.set(folder)
    def log_line(self,message):
        self.log.configure(state='normal');self.log.insert('end',message+'\n');self.log.see('end');self.log.configure(state='disabled')
    def start(self):
        if self.busy:return
        domain=self.domain.get().strip()
        if not domain.isdecimal(): messagebox.showerror('Domain ID','Enter a numeric Five9 domain ID.');return
        if not self.client_id.get().strip() or not self.secret.get():messagebox.showerror('Credentials','Enter your Client ID and Client Secret.');return
        args=(domain,self.client_id.get(),self.secret.get(),self.token_url.get().strip(),self.method.get(),self.scope.get(),self.out.get())
        try:
            SETTINGS.parent.mkdir(parents=True,exist_ok=True)
            SETTINGS.write_text(json.dumps({'domain':domain,'output':self.out.get(),'method':self.method.get(),'scope':self.scope.get()},indent=2),encoding='utf-8')
        except OSError:pass
        self.busy=True;self.button.configure(state='disabled');self.progress.start(12);self.status.set('Connecting to Five9…');self.log_line('Requesting OAuth access token…')
        threading.Thread(target=self.worker,args=args,daemon=True).start()
    def worker(self,domain,client_id,secret,token_url,method,scope,output):
        try:
            token=get_access_token(client_id,secret,token_url,method,scope)
            self.events.put(('log','OAuth access token received. Fetching Assistances…'))
            # extractor uses read-only GET and follows Five9 paging.next.
            pages=extractor.api_fetch(domain,token,100,30)
            count=sum(len(extractor.payload_items(p)) for p in pages)
            self.events.put(('log',f'Retrieved {count} records across {len(pages)} pages. Creating workbook…'))
            extractor.export(pages,Path(output))
            self.events.put(('done',(count,len(pages),str(Path(output)/'Five9_Digital_Assistances.xlsx'))))
        except Exception as exc:
            # Only our own safe error messages are displayed; never expose request headers, secrets, or tokens.
            self.events.put(('error',str(exc)))
    def poll(self):
        try:
            while True:
                kind,data=self.events.get_nowait()
                if kind=='log':self.log_line(data)
                elif kind=='done':
                    count,pages,path=data;self.last_xlsx=path
                    self.status.set(f'Export complete: {count} records retrieved, {pages} page(s).')
                    self.log_line(f'Workbook saved: {path}');self.finish()
                    messagebox.showinfo('Export complete',f'Retrieved {count} records across {pages} page(s).\n\nSaved to:\n{path}')
                elif kind=='error':
                    self.status.set('Export failed. See the message below.');self.log_line('ERROR: '+data);self.finish()
                    messagebox.showerror('Five9 export error',data[:1800])
        except queue.Empty:pass
        self.after(100,self.poll)
    def finish(self):self.busy=False;self.button.configure(state='normal');self.progress.stop()
    def open_folder(self):
        folder=Path(self.out.get());folder.mkdir(parents=True,exist_ok=True)
        if os.name=='nt':os.startfile(str(folder))
        else:webbrowser.open(folder.as_uri())
    def open_excel(self):
        if not self.last_xlsx or not Path(self.last_xlsx).exists():messagebox.showinfo('No export yet','Complete an export first.');return
        if os.name=='nt':os.startfile(self.last_xlsx)
        else:webbrowser.open(Path(self.last_xlsx).as_uri())

if __name__=='__main__':App().mainloop()
