@echo off
cd /d "%~dp0"
py -m pip install -r requirements.txt
if errorlevel 1 goto failed
py -m playwright install chromium
if errorlevel 1 goto failed
echo Setup complete.
pause
exit /b 0
:failed
echo Installation failed. Check output above.
pause
exit /b 1
