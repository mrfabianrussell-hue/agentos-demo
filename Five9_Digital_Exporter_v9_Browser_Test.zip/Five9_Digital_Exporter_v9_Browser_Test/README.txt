Five9 Digital Assistances Exporter v9 - BROWSER-ASSISTED EXPERIMENTAL TEST

This is not an official Five9 integration and is not verified with live Five9.

How it works: a temporary Chromium browser opens to the Five9 Admin Console.
Sign in directly to Five9, open Digital > Assistances, and browse through all
pages. The application observes successful assistance JSON responses in that
browser and exports them to Excel. It does NOT read passwords, request headers,
Bearer tokens, cookies, or local browser storage. It does NOT call the API with
a separate OAuth client. It does not bypass Five9 authorization.

SETUP ON WINDOWS
1. Extract the ZIP.
2. Run Install_Dependencies.bat (requires Python 3 and network for Chromium).
3. Run Launch_Exporter.bat.
4. Confirm Domain ID; click Open Five9 Sign-in.
5. Log in directly in the browser, open Digital > Assistances.
6. Navigate through all assistance pages (Next / pagination) until the last.
7. Click Export Captured Assistances. Verify record count against Five9.

LIMITATIONS
- The Admin Console may use a different request path or not request every page.
- UI pagination may not correspond to API pagination; incomplete results possible.
- This prototype may not capture any responses, even when the UI displays data.
- If the server returns next-page cursors, manually navigating all UI pages
  does not guarantee all API pages were retrieved. Check record counts.
- Browser sessions are temporary and close when you close the browser.
- Exports contain sensitive business content; store in approved locations.
- This is a test utility, not a production-ready, supported Five9 integration.
- No executable is provided; requires Python and Playwright Chromium install.

Output: Five9_Digital_Assistances.xlsx and Five9_Assistances_Raw.json.
Read-only: no POST, PUT, PATCH, DELETE calls are made by the exporter. The
Five9 Admin Console itself may make its normal requests while you navigate.
