# Agent Support — Operations Center 2.0

Use **OPERATIONS-CENTER-START-HERE.md** for the combined startup, upgrade, grouping, sorting, standards, backup/restore and Azure instructions.

Start-Operations-Center.ps1 now connects both dashboards with one account. Start-Agent-Support.ps1 remains a compatibility wrapper for that same launcher.
