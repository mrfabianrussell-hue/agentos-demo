# Operations Center 2.0 — start here

## 1. Upgrade without losing your settings

Stop the previous server with Ctrl+C. Extract this ZIP into a new folder. Keep the old folder until your configuration is migrated.

In PowerShell, from the new folder, run:

```powershell
.\Start-Operations-Center.ps1 -PreviousFolder "C:\path\to\your\previous\build"
```

Replace that example path with your old extracted folder. If this is a fresh installation, omit -PreviousFolder. If script policy blocks execution for this process:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Start-Operations-Center.ps1 -PreviousFolder "C:\path\to\your\previous\build"
```

The launcher imports the previous data/agent-workspace.json and remembered duration-unit setting only when the stable destination files do not already exist. It never overwrites an existing destination configuration. Your data now lives in `%LOCALAPPDATA%\Five9OperationsCenter`, outside the ZIP folder, so future extracted builds use the same configuration. Passwords and session tokens are not saved.

Existing wallboard views were browser-local. Open the wallboard using the same localhost URL/browser and save each desired configuration through Manage views once; this publishes it to the shared server configuration and includes it in backups. A complete backup can also be restored through Connection & backup.

## 2. Sign in once

Enter one Five9 Supervisor account. The account needs access to Statistics Web Services. Agent Groups and the full skill catalog additionally need read access to Configuration Web Services. The application never calls a create/modify/delete operation in Five9.

The source uses millisecond durations, matching the Statistics API reference and your validated values. The launcher remembers a prior unit; `-ResetDurationUnit` changes it. `-Port 3001` uses another local port. `-NoBrowser` suppresses browser launch. If the port is already occupied, the launcher asks you to stop the old server. Do not run competing local sessions under this Five9 account.

Open the following links and leave PowerShell running:

- `http://localhost:3000/` — skill wallboard.
- `http://localhost:3000/agents.html` — agent support.
- `http://localhost:3000/connection.html` — feed health, diagnostics and backup/restore.

The browser opens Connection & backup automatically. Refresh once if it opens before Node has started. Agent/queue statistics refresh at 60 seconds; the browser checks every 15 seconds. Group/catalog metadata is refreshed every 15 minutes after success or every 5 minutes after an error.

## 3. Understand the shared feed

A single Statistics Web Services session requests:

- AgentStatistics: current-day call totals, AHT, talk, hold and wrap time.
- AgentState: current state, duration and reason.
- ACDStatus: skill queue counts, longest current queue time and agent-state counts.

Each feed has its own health indicator. A configuration-permission error leaves live statistics available. An AgentState error leaves agent totals available with Partial data; current duration fields remain unavailable. A queue error does not blank live agent statistics. Missing or unverified fields show —. Service level, volume and skill-level ACW remain unavailable until a valid statistic source is mapped; campaign values are not mislabeled as skill values.

The full skill catalog comes from getSkills when permitted; otherwise the available list contains the skill names returned by ACDStatus. A skill appearing in the full catalog without an ACD row has no queue statistic in the current response; it shows — rather than zero.

## 4. Filter and sort agents

The default activity filter is **Working now**, which excludes Logged Out and Unknown states. **Calls today** includes agents with Total Calls > 0, including those now logged out; Total Calls can include events other than completed handled calls. **All agents** displays all returned rows.

Five9 Agent Group filtering uses native group IDs and username membership. Agents may have several groups. An agent appears once in an overall view, while matching any selected group. Legacy team/site labels are optional local assignments and remain independent of Five9 groups.

Click each table header to sort; click again to reverse. Agent and Current state are separate sort controls in the first column. Duration sorting uses numeric values; missing values stay last in both directions. Priority sorts severity, then the number/persistence of flags. Review sorts review status, not review timestamp. The dropdown provides the same options.

When you open an agent, the table keeps its current order while values refresh. The detail panel shows the time of its snapshot; **Refresh agent values** updates it while preserving the review text/status you are entering. Closing the panel applies the latest sort order.

## 5. Standards and group precedence

Times display and accept HH:MM:SS. Goals are performance expectations; Warning/Critical are alert limits. Watch can mean a goal is exceeded or an alert is still awaiting enough fresh observations. It does not mean a sustained warning has already fired.

Drafts do not affect published alerts. Save draft, inspect Impact preview, then publish. A fresh installation has drafts but no published standards. Existing publications are retained during migration. Preview ignores persistence and does not prove a breach is sustained.

Advanced settings contains minimum total calls, fresh update count, persistence, group, team/site scope, exclusions and precedence.

For competing enabled rules of the same metric:

1. Matching Agent Group scope outranks a general rule. A group plus team/site scope is narrower still.
2. Within equal specificity, higher precedence wins.
3. If still tied, the stricter warning limit wins.
4. A final equal tie is resolved by stable rule ID.

Agent detail displays each standard's scope. Rules overridden by a winner are marked Superseded. Group-specific rules require current group metadata; unavailable/stale group membership does not silently evaluate against assumed membership. Logged-out agents remain excluded from active alerts, although their current-day statistics can be viewed. An overall counter counts each agent once, even when several flags exist. Group summary counts are independent; agents in multiple groups can contribute to each group, so group rows must not be added as a unique total. Shared-pattern prompts use native groups and display the three largest patterns.

## 6. Views and shared configuration

Agent views save group, activity, team/site, focus and sort. Skill views save selected skills, columns, sort and thresholds. Both are stored centrally by the Node server. Changes are visible to other browsers on that same server. View links use `/agents.html?view=<key>` or `/?view=<id>`; a URL selects a configuration and never grants editing permission.

Reviews and snoozes do not clear flags. Snoozes require a reason and expire; they remain visible in counters. Group summary hides names as a presentation mode, not an authorization boundary.

## 7. Connection status and complete backup

Connection & backup displays successful update times and errors for the statistics session, agent totals, states, queue statistics, Agent Groups and full catalog. Copy diagnostic summary includes counts, statuses and timing samples but not credentials or agent identities. Do not share complete configuration backups outside your authorized team: they include assignments/reviews with internal agent identifiers.

Download complete backup includes rules, drafts, both view types, assignments, reviews and audit history. Restore displays the content counts first. Press Restore this configuration to apply it; the server validates content and checks the revision so another editor's changes cannot be overwritten silently. The previous configuration is backed up before restore. The last 20 configuration versions live in the data folder's backups subdirectory.

Standards-only exports remain in Standards & preview. They are not complete backups and must not be used as complete restore files.

## 8. Azure handoff

Deploy the Node application with startup `npm start`. Use Entra sign-in and Require authentication in App Service. Set `AUTH_REQUIRED=true`, `NODE_ENV=production`, and assign app role `Dashboard.Editor` to your 1–5 editors. Other authenticated users are viewers. Both agent and wallboard configuration writes enforce Editor server-side; viewer-only filtering/sorting does not publish changes.

Set FIVE9_USERNAME and a Key Vault reference for FIVE9_PASSWORD. Set FIVE9_DURATION_UNIT=milliseconds, FIVE9_AGENT_POLL_SECONDS=60, FIVE9_STATS_TIMEZONE=America/New_York, and AGENT_CONFIG_PATH to persistent writable storage such as `/home/data/agent-workspace.json` when configured in App Service. One Node instance is required for the current in-process session, file locks and snapshot cache.

Default validated agent endpoint: `https://api.five9.com/wssupervisor/v11/SupervisorWebService`, namespace `http://service.supervisor.ws.five9.com/`. Configuration reads use `https://api.five9.com/wsadmin/v13/AdminWebService`. These endpoints can be overridden with FIVE9_AGENT_SOAP_ENDPOINT, FIVE9_AGENT_SOAP_NAMESPACE and FIVE9_CONFIG_ENDPOINT. Regional/custom account access must be validated by your team. No live credentials are embedded in the ZIP or published interface.

## 9. Acceptance checks before production

- Compare ACD calls waiting, longest wait and agent-state counts with Five9 Supervisor for the five operational skills; this queue source is new.
- Verify the account can read native groups and the full skill catalog. If denied, confirm the read permissions rather than granting blanket write access.
- Verify two agents with multiple groups filter correctly and are not double counted.
- Set a group-specific rule plus a general rule; confirm the correct winner and scope explanation.
- Confirm all eight table columns sort in both directions and missing durations stay last.
- Confirm a detail panel holds row order, refreshes on request and preserves in-progress review notes.
- Compare agent AHT, ACW and current-state duration as you did with the previous build.
- Download/restore a backup and verify standards, views and reviews; test revision conflicts with two editors.
- Verify Viewer receives 403 on direct writes and backup downloads; Editor can publish.
- Restart the server and verify configuration survives; stop the upstream connection and confirm stale/error status without fabricated values.

Historical reporting, Azure Blob-backed storage and multi-instance feed coordination are not implemented in this release. Live account and Windows launcher testing remain your environment's final validation steps.
