# Operations Center 2.0

One Node application serves the skill wallboard (`/`), Agent Support (`/agents.html`), and Connection & backup (`/connection.html`). One Five9 Supervisor credential prompt opens one Statistics Web Services session for AgentStatistics, AgentState and ACDStatus. Agent Groups and the full skill catalog use separate read-only Configuration Web Services calls with those same credentials. No separate Supervisor REST session is opened by the application.

Start with **OPERATIONS-CENTER-START-HERE.md**. Existing Start-Local.ps1 and Start-Agent-Support.ps1 delegate to the combined launcher. The application contains no sample agents or simulated metrics. When disconnected, it explicitly shows unavailable data.

Node.js 20+ is required. No npm install is required. Run `npm test` to execute the automated checks.

Secrets stay in process memory locally. In Azure, use App Service Entra authentication with Require authentication, `AUTH_REQUIRED=true`, and assign the `Dashboard.Editor` app role only to editors. All configuration writes, including skill-view changes and full restore, enforce that role on the server and check request origin. Authenticated viewers can sort and filter without saving configuration.

Use one Node instance with persistent writable configuration storage. Configuration backups are retained before each change; the last 20 versions are stored beside the configuration file. Azure Blob-backed persistence, multi-instance feed coordination and historical reporting are not implemented. The published static website provides the operational interface; the live Five9 connection requires the local or Azure Node backend.

Relevant Five9 sources: Statistics Web Services API guide (AgentStatistics, AgentState, ACDStatus and millisecond time values); Configuration Web Services reference (getAgentGroups and getSkills). The new combined ACD source and group read permissions must be validated with your account before production use.
