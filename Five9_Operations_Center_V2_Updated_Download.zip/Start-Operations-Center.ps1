param([int]$Port = 3000, [switch]$ResetDurationUnit, [string]$PreviousFolder = '', [switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
$names = @('FIVE9_USERNAME','FIVE9_PASSWORD','FIVE9_AGENT_USERNAME','FIVE9_AGENT_PASSWORD','FIVE9_AGENT_DURATION_UNIT','FIVE9_DURATION_UNIT','FIVE9_AGENT_POLL_SECONDS','FIVE9_STATS_TIMEZONE','AGENT_CONFIG_PATH','PORT','AUTH_REQUIRED','NODE_ENV')
$prior = @{}
foreach ($name in $names) { $prior[$name] = [Environment]::GetEnvironmentVariable($name,'Process') }
try {
    $version = (& node --version 2>$null)
    if ($LASTEXITCODE -ne 0 -or [int](($version -replace '^v','').Split('.')[0]) -lt 20) { throw 'Install Node.js 20 or newer, then reopen PowerShell.' }
    $listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $Port)
    try { $listener.Start() } catch { throw "Port $Port is already in use. Stop the old dashboard with Ctrl+C, or use -Port 3001." } finally { $listener.Stop() }
    Write-Host 'Operations Center - one Five9 connection for both dashboards' -ForegroundColor Cyan
    Write-Host 'Use a Supervisor account with Statistics Web Services access. Agent Groups and full skill catalog also require Configuration Web Services read access.'
    Write-Host 'Stop other local apps using this account. This application opens one statistics session; it does not start a separate REST session.'
    $account = Get-Credential -Message 'Five9 Supervisor account for Operations Center'
    if (-not $account) { throw 'No credentials entered.' }
    $env:FIVE9_USERNAME = $account.UserName
    $env:FIVE9_PASSWORD = $account.GetNetworkCredential().Password
    $env:FIVE9_AGENT_USERNAME = ''
    $env:FIVE9_AGENT_PASSWORD = ''
    $dataPath = Join-Path $env:LOCALAPPDATA 'Five9OperationsCenter'
    New-Item -ItemType Directory -Path $dataPath -Force | Out-Null
    $oldData = if ($PreviousFolder) { Join-Path (Resolve-Path $PreviousFolder).Path 'data' } else { Join-Path $PSScriptRoot 'data' }
    foreach ($file in @('agent-workspace.json','agent-duration-unit.json')) {
        $source = Join-Path $oldData $file
        $target = Join-Path $dataPath $file
        if ((Test-Path $source) -and -not (Test-Path $target)) { Copy-Item $source $target; Write-Host "Imported existing $file" }
    }
    $settingsPath = Join-Path $dataPath 'agent-duration-unit.json'
    $unit = 'milliseconds'
    if ((Test-Path $settingsPath) -and -not $ResetDurationUnit) {
        try { $saved = Get-Content $settingsPath -Raw | ConvertFrom-Json; if ($saved.unit -in @('unknown','seconds','milliseconds')) { $unit = $saved.unit } } catch { Write-Host 'Using documented milliseconds duration units.' }
    }
    if ($ResetDurationUnit) {
        $answer = Read-Host 'Duration unit: milliseconds, seconds, or unknown (Enter = milliseconds)'
        if ($answer -and $answer -notin @('unknown','seconds','milliseconds')) { throw 'Enter milliseconds, seconds, or unknown.' }
        $unit = if ($answer) { $answer } else { 'milliseconds' }
    }
    @{unit=$unit} | ConvertTo-Json | Set-Content -Path $settingsPath -Encoding UTF8
    $env:FIVE9_DURATION_UNIT = $unit
    $env:FIVE9_AGENT_DURATION_UNIT = $unit
    $env:FIVE9_AGENT_POLL_SECONDS = '60'
    $env:FIVE9_STATS_TIMEZONE = 'America/New_York'
    $env:AGENT_CONFIG_PATH = Join-Path $dataPath 'agent-workspace.json'
    $env:PORT = [string]$Port
    $env:AUTH_REQUIRED = 'false'
    $env:NODE_ENV = 'development'
    Write-Host "Data folder: $dataPath. Duration units: $unit. No credentials are stored." -ForegroundColor Cyan
    Write-Host "Skill wallboard: http://localhost:$Port/"
    Write-Host "Agent support: http://localhost:$Port/agents.html"
    Write-Host "Connection and backup: http://localhost:$Port/connection.html"
    Write-Host 'Leave this window open. Press Ctrl+C to stop. Allow up to a minute for statistics; metadata can take longer.'
    if (-not $NoBrowser) { Start-Process "http://localhost:$Port/connection.html" }
    & node server/index.js
} finally {
    foreach ($name in $names) { [Environment]::SetEnvironmentVariable($name,$prior[$name],'Process') }
    Pop-Location
}
