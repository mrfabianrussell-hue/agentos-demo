import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createServer} from 'node:net';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
test('HTTP API enforces authentication, editor role and save origin',async()=>{
 const probe=createServer();await new Promise(r=>probe.listen(0,'127.0.0.1',r));const port=probe.address().port;await new Promise(r=>probe.close(r));
 const dir=await mkdtemp(join(tmpdir(),'agent-http-'));
 const child=spawn(process.execPath,['server/index.js'],{cwd:new URL('../',import.meta.url),env:{...process.env,PORT:String(port),NODE_ENV:'production',AUTH_REQUIRED:'true',FIVE9_USERNAME:'',FIVE9_PASSWORD:'',FIVE9_AGENT_USERNAME:'',FIVE9_AGENT_PASSWORD:'',AGENT_CONFIG_PATH:join(dir,'state.json')},stdio:'ignore'});
 const url=`http://127.0.0.1:${port}`,principal=roles=>Buffer.from(JSON.stringify({claims:roles.map(val=>({typ:'roles',val}))})).toString('base64');
 try{let ready=false;for(let i=0;i<60;i++){try{await fetch(url+'/api/agents');ready=true;break}catch{await new Promise(r=>setTimeout(r,25))}}assert.ok(ready,'server starts');
 assert.equal((await fetch(url+'/api/agents')).status,401);
 const viewer={'x-ms-client-principal':principal(['Dashboard.Viewer']),'Content-Type':'application/json',Origin:url};
 let response=await fetch(url+'/api/agent-workspace',{headers:viewer});const w=await response.json();assert.equal(w.canEdit,false);
 assert.equal((await fetch(url+'/api/agent-workspace',{method:'POST',headers:viewer,body:JSON.stringify({action:'publish',revision:w.revision})})).status,403);
 assert.equal((await fetch(url+'/api/backup',{headers:viewer})).status,403);
 assert.equal((await fetch(url+'/api/agent-workspace',{method:'POST',headers:viewer,body:JSON.stringify({action:'wallboard',views:[],revision:w.revision})})).status,403);
 const editor={...viewer,'x-ms-client-principal':principal(['Dashboard.Editor'])};
 assert.equal((await fetch(url+'/api/agent-workspace',{method:'POST',headers:{...editor,Origin:'https://another.example'},body:JSON.stringify({action:'publish',revision:w.revision})})).status,400);
 response=await fetch(url+'/api/agent-workspace',{method:'POST',headers:editor,body:JSON.stringify({action:'draft',rules:w.rules,revision:w.revision})});assert.equal(response.status,200);
 assert.equal((await fetch(url+'/agents.html',{headers:viewer})).status,200);
 assert.equal((await fetch(url+'/api/agents',{headers:viewer})).status,200);
 const backup=await fetch(url+'/api/backup',{headers:editor});assert.equal(backup.status,200);assert.equal((await backup.json()).format,'operations-center-backup-v2');
 assert.equal((await fetch(url+'/api/connection',{headers:viewer})).status,200);
 }finally{child.kill('SIGTERM');await new Promise(r=>{child.once('exit',r);setTimeout(r,2000).unref()});await rm(dir,{recursive:true,force:true})}
});
