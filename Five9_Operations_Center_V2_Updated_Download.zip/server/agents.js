import {parseStatistics} from './discover.js';
const escape=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
export function seconds(v,unit='seconds'){if(v==null||String(v).trim()==='')return null;const s=String(v).trim();if(/^\d+:\d{2}:\d{2}(\.\d+)?$/.test(s)){const [h,m,z]=s.split(':').map(Number);return h*3600+m*60+z}if(/^\d+:\d{2}(\.\d+)?$/.test(s)){const [m,z]=s.split(':').map(Number);return m*60+z}const n=Number(s);return ['seconds','milliseconds'].includes(unit)&&Number.isFinite(n)&&n>=0?n/(unit==='milliseconds'?1000:1):null}
const number=v=>v!=null&&String(v).trim()!==''&&Number.isFinite(Number(v))?Number(v):null;
export function normalizeAgents(stats,states,unit='seconds',statisticsDay=''){
 const valid=r=>r.Username&&String(r.Username).trim()&&!['[none]','none','total','[total]'].includes(String(r.Username).trim().toLowerCase());
 const key=r=>String(r.Username).trim().toLowerCase();
 const stateMap=new Map(states.rows.filter(valid).map(r=>[key(r),r]));
 const users=new Map(stats.rows.filter(valid).map(r=>[key(r),r]));for(const id of stateMap.keys())if(!users.has(id))users.set(id,{});
 return [...users].map(([id,r])=>{const s=stateMap.get(id)||{},state=s.State||'Unknown',duration=seconds(s['State Duration'],unit);return {id:String(r.Username||s.Username||id).trim(),name:r['Full Name']||s['Full Name']||id,state,reason:s['Reason Code']||'',stateDuration:duration,stateSince:s['State Since']||null,statisticsDay,calls:number(r['Total Calls']),inbound:number(r['Total Inbound Calls']),outbound:number(r['Total Outbound Calls']),manual:number(r['Total Manual Calls']),aht:seconds(r['Avg Handle Time'],unit),talk:seconds(r['Avg Talk Time'],unit),hold:seconds(r['Avg Hold Time'],unit),acw:seconds(r['Avg Wrap Time'],unit),currentAcw:/after call work|wrap/i.test(state)?duration:duration!=null?0:null,currentCall:/on call/i.test(state)?duration:duration!=null?0:null,notReady:/not ready/i.test(state)?duration:duration!=null?0:null,occupancy:r.Occupancy??null,utilization:r.Utilization??null};});
}
export function timezoneOffset(zone,date=new Date()){const parts=new Intl.DateTimeFormat('en-US',{timeZone:zone,timeZoneName:'longOffset'}).formatToParts(date);const v=parts.find(p=>p.type==='timeZoneName').value;const m=v.match(/GMT([+-])(\d{2}):(\d{2})/);return m?(m[1]==='-'?-1:1)*(Number(m[2])*60+Number(m[3]))*60000:0}
export class AgentFeed {
 constructor(env=process.env,fetcher=fetch){this.env=env;this.fetcher=fetcher;this.configured=!!(env.FIVE9_AGENT_USERNAME&&env.FIVE9_AGENT_PASSWORD);this.endpoint=env.FIVE9_AGENT_SOAP_ENDPOINT||'https://api.five9.com/wssupervisor/v11/SupervisorWebService';this.ns=env.FIVE9_AGENT_SOAP_NAMESPACE||'http://service.supervisor.ws.five9.com/';this.zone=env.FIVE9_STATS_TIMEZONE||'America/New_York';this.unit=env.FIVE9_AGENT_DURATION_UNIT||'unknown';this.interval=Math.max(30,Number(env.FIVE9_AGENT_POLL_SECONDS)||60)*1000;this.cookie='';this.connected=false;this.running=false;this.state={mode:'live',status:this.configured?'connecting':'unconfigured',agents:[],updatedAt:null,message:null,window:'CurrentDay',timezone:this.zone,durationUnit:this.unit};this.timer=null}
 async call(method,body=''){
  const u=new URL(this.endpoint);if(u.protocol!=='https:'||!/(^|\.)five9\.(com|eu)$/.test(u.hostname))throw new Error('Agent SOAP endpoint must be HTTPS on a Five9 host');
  const response=await this.fetcher(this.endpoint,{method:'POST',headers:{'Content-Type':'text/xml;charset=UTF-8',SOAPAction:'""',Authorization:'Basic '+Buffer.from(`${this.env.FIVE9_AGENT_USERNAME}:${this.env.FIVE9_AGENT_PASSWORD}`).toString('base64'),...(this.cookie?{Cookie:this.cookie}:{})},body:`<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="${escape(this.ns)}"><soapenv:Header/><soapenv:Body><ser:${method}>${body}</ser:${method}></soapenv:Body></soapenv:Envelope>`,signal:AbortSignal.timeout(18000)});
  const cookies=response.headers?.getSetCookie?.()||[];if(cookies.length)this.cookie=cookies.map(c=>c.split(';')[0]).join('; ');
  if(!response.ok)throw new Error(`Five9 agent statistics ${method}: HTTP ${response.status}`);
  const xml=await response.text();if(/<(?:[\w.-]+:)?faultstring\b/.test(xml))throw new Error(`Five9 agent statistics ${method}: SOAP fault. Check Supervisor permission, API access, and the configured endpoint/namespace.`);return xml;
 }
 async tick(){if(!this.configured||this.running)return;this.running=true;try{const offset=timezoneOffset(this.zone);if(!this.connected||offset!==this.offset){await this.call('setSessionParameters',`<viewSettings><forceLogoutSession>false</forceLogoutSession><rollingPeriod>Minutes30</rollingPeriod><shiftStart>0</shiftStart><statisticsRange>CurrentDay</statisticsRange><timeZone>${offset}</timeZone></viewSettings>`);this.connected=true;this.offset=offset}
 const stats=parseStatistics(await this.call('getStatistics','<statisticType>AgentStatistics</statisticType>'));
 const states=parseStatistics(await this.call('getStatistics','<statisticType>AgentState</statisticType>'));
 if(!stats.columns.includes('Username')||!states.columns.includes('Username'))throw new Error('Five9 agent statistics missing Username column; mapping requires validation');
 const now=new Date(),day=new Intl.DateTimeFormat('en-CA',{timeZone:this.zone,year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
 const durationColumns=['Avg Handle Time','Avg Hold Time','Avg Talk Time','Avg Wrap Time'];
 const samples=stats.rows.filter(r=>number(r['Total Calls'])>0).slice(0,3).map(r=>Object.fromEntries(durationColumns.map(c=>[c,r[c]??null])));
 const stateSamples=states.rows.filter(r=>r.State).slice(0,3).map(r=>({State:r.State,'State Duration':r['State Duration']??null}));
 this.state={...this.state,status:'live',updatedAt:now.toISOString(),diagnostics:{statisticsRows:stats.rows.length,stateRows:states.rows.length,numericDurationUnit:this.unit,durationSamples:samples,stateSamples},agents:normalizeAgents(stats,states,this.unit,day),message:null,columns:{statistics:stats.columns.filter(c=>['Username','Full Name','Total Calls','Total Inbound Calls','Total Outbound Calls','Avg Handle Time','Avg Talk Time','Avg Hold Time','Avg Wrap Time'].includes(c)),state:states.columns.filter(c=>['Username','Full Name','State','State Duration','Reason Code'].includes(c))}};
 }catch(e){this.connected=false;this.cookie='';this.state={...this.state,status:this.state.updatedAt?'stale':'error',message:String(e.message).slice(0,240)}}finally{this.running=false}}
 start(){if(!this.configured||this.timer)return;void this.tick();this.timer=setInterval(()=>void this.tick(),this.interval);this.timer.unref?.()}
 getState(){return this.state.status==='live'&&Date.now()-Date.parse(this.state.updatedAt)>this.interval*3?{...this.state,status:'stale',message:'Agent snapshot is overdue'}:this.state}
 async stop(){clearInterval(this.timer);if(this.connected)try{await this.call('closeSession')}catch{}this.connected=false}
}
