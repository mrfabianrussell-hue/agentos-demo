import test from 'node:test';
import assert from 'node:assert/strict';
import {parseStatistics} from './discover.js';

test('parses SOAP statistics columns and rows without attaching an agent record',()=>{
 const xml='<env:Envelope><env:Body><ns2:getStatisticsResponse><return><columns><values><data>Campaign Name</data><data>Service Level (Queue)</data><data>Handled Calls</data></values></columns><rows><values><data>Inbound A</data><data>87.4</data><data>42</data></values></rows><timestamp>123</timestamp></return></ns2:getStatisticsResponse></env:Body></env:Envelope>';
 assert.deepEqual(parseStatistics(xml),{columns:['Campaign Name','Service Level (Queue)','Handled Calls'],rows:[{'Campaign Name':'Inbound A','Service Level (Queue)':'87.4','Handled Calls':'42'}]});
});
test('rejects an upstream SOAP fault',()=>{
 assert.throws(()=>parseStatistics('<Fault><faultstring>Unsupported statistic type</faultstring></Fault>'),/Unsupported statistic/);
});
test('nil and self-closing cells preserve subsequent agent column positions',()=>{
 const xml='<return><columns><data>Unused</data><data>Username</data><data>Full Name</data><data>State</data><data>State Duration</data></columns><rows><data/><data>agent@example.test</data><data xsi:nil="true"/><data>On call</data><data>123000</data></rows></return>';
 assert.deepEqual(parseStatistics(xml).rows[0],{Unused:null,Username:'agent@example.test','Full Name':null,State:'On call','State Duration':'123000'});
});
test('blank fields and namespaces preserve zeros without swallowing the next cell',()=>{
 const xml='<return><columns><data>Username</data><data>Avg Handle Time</data><data>Avg Wrap Time</data><data>Total Calls</data></columns><rows><x:data>a</x:data><x:data /><x:data>0</x:data><x:data>12</x:data></rows></return>';
 const r=parseStatistics(xml).rows[0];assert.equal(r['Avg Handle Time'],null);assert.equal(r['Avg Wrap Time'],'0');assert.equal(r['Total Calls'],'12');
});
