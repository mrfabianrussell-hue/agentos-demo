import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { OperationsFeed } from './operations.js';
import { AgentStore, identity } from './agent-store.js';

const root = resolve(fileURLToPath(new URL('../dist/', import.meta.url)));
const feed = new OperationsFeed();
const types = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml'};
const authRequired = process.env.AUTH_REQUIRED === 'true';
if (process.env.NODE_ENV === 'production' && !authRequired) throw new Error('Set AUTH_REQUIRED=true and require authentication in Azure App Service');
feed.start();
const agents=feed;
const agentStore=new AgentStore(resolve(process.env.AGENT_CONFIG_PATH||'data/agent-workspace.json'));

const server = createServer(async (req,res) => {
  // Azure App Service Authentication must be set to Require authentication.
  // This header is a secondary check; it is not a substitute for the platform gate.
  if (authRequired && !req.headers['x-ms-client-principal']) {
    res.writeHead(401, {'Content-Type':'application/json','Cache-Control':'no-store'});
    res.end(JSON.stringify({error:'Authentication required'})); return;
  }
  const pathname = new URL(req.url || '/', 'http://localhost').pathname;
  if(pathname==='/api/connection'&&req.method==='GET'){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(feed.connection()));return}
  if(pathname==='/api/backup'&&req.method==='GET'){if(!identity(req).editor){res.writeHead(403);res.end();return}const w=await agentStore.get();res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store','Content-Disposition':'attachment; filename=operations-center-backup.json'});res.end(JSON.stringify({format:'operations-center-backup-v2',exportedAt:new Date().toISOString(),workspace:w},null,2));return}
  if (pathname === '/api/agents' && req.method === 'GET') {
    res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});
    res.end(JSON.stringify(agents.getState())); return;
  }
  if (pathname === '/api/agent-workspace') {
    const user=identity(req);
    try {
      if(req.method==='GET') {const state=await agentStore.get();res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify({...state,canEdit:user.editor}));return}
      if(req.method!=='POST'){res.writeHead(405);res.end();return}
      if(!user.editor){res.writeHead(403,{'Content-Type':'application/json'});res.end(JSON.stringify({error:'Editor role required'}));return}
      const origin=req.headers.origin;
      if(!origin||new URL(origin).host!==req.headers.host)throw new Error('Same-origin editor request required');
      let body='';for await(const chunk of req){body+=chunk;if(body.length>2000000)throw new Error('Configuration is too large')}
      const state=await agentStore.update(JSON.parse(body),user.name);
      res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify({...state,canEdit:true}));return;
    }catch(err){res.writeHead(err.status||400,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify({error:err.message}));return}
  }
  if (pathname === '/api/live' && req.method === 'GET') {
    res.writeHead(200, {'Content-Type':'application/json','Cache-Control':'no-store'});
    res.end(JSON.stringify(feed.getQueues())); return;
  }
  if (pathname.startsWith('/api/')) {res.writeHead(404);res.end();return}
  const filename = resolve(root, '.' + decodeURIComponent(pathname === '/' ? '/index.html' : pathname));
  if (filename !== root && !filename.startsWith(root + sep)) {res.writeHead(403);res.end();return}
  try {
    const info = await stat(filename);
    if (!info.isFile()) throw new Error('Not a file');
    const bytes = await readFile(filename);
    res.writeHead(200, {'Content-Type':types[extname(filename)] || 'application/octet-stream','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});
    res.end(bytes);
  } catch {res.writeHead(404);res.end('Not found')}
});
server.listen(Number(process.env.PORT) || 3000, process.env.NODE_ENV === 'production' ? '0.0.0.0' : '127.0.0.1', () => {
  if (process.env.NODE_ENV !== 'production') console.log(`Local dashboard ready at http://localhost:${process.env.PORT || 3000}`);
});
for (const signal of ['SIGINT','SIGTERM']) process.once(signal, async () => {
  server.close();
  await feed.stop();

  process.exit(0);
});
