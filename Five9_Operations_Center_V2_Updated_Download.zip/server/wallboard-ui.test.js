import test from 'node:test';import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';
test('wallboard starts without fabricated values and disconnected status is actionable',async()=>{
 const controls=new Map();const element=s=>{if(!controls.has(s))controls.set(s,{value:'',innerHTML:'',textContent:'',hidden:false,dataset:{},classList:{contains:()=>false,toggle(){},add(){},remove(){}},setAttribute(){},focus(){}});return controls.get(s)};
 const document={querySelector:element,querySelectorAll:()=>[],addEventListener(){}};
 const code=await readFile(new URL('../dist/app.js',import.meta.url),'utf8');
 const run=new Function('document','localStorage','location','window','fetch','setInterval','setTimeout',code+';return {read:()=>({badge:document.querySelector(".feedbadge").textContent,rows:document.querySelector("#rows").innerHTML}),poll:checkLive};');
 const context=run(document,{getItem:()=>null,setItem(){}},{href:'https://example.test/'},{history:{replaceState(){}}},async url=>({ok:true,headers:{get:()=> 'application/json'},json:async()=>url.includes('workspace')?{revision:1,wallboardViews:[],canEdit:false}:{mode:'live',status:'unconfigured',skills:[],catalog:[],updatedAt:null}}),()=>0,()=>0);
 await context.poll();const r=context.read();assert.equal(r.badge,'NOT CONNECTED');assert.ok(r.rows.includes('Awaiting Five9 data'));assert.equal(r.rows.includes('Simulated'),false);assert.equal(controls.get('#configure').hidden,true);
});
