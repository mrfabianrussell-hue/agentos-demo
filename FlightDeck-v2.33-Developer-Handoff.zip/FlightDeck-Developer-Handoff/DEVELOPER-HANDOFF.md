# FlightDeck v2.33 — Developer Ownership Handoff

Prepared October 30, 2026 · Based on the supplied FlightDeck-v2.33 (1).zip

## 1. Start here

FlightDeck is a browser-based knowledge application for mortgage servicing agents. Administrators map and review procedures from a source manual PDF, export a knowledge pack, and make the pack and matching PDF available to agents. Agents search, browse, follow incoming context links, and view the original manual pages.

This is a vanilla HTML/CSS/JavaScript application, not a React project. The delivered HTML files contain editable application code and bundled dependencies. There is no package.json, npm build, server application, database service, Dockerfile, or deployment pipeline in the supplied package. An ordinary static web server can serve the application. A container would initially provide that web server; it would not create a shared database or publishing API.

**First objective:** reproduce the current experience before refactoring it. Preserve a baseline in source control, obtain a real released knowledge JSON/PDF pair, and run through the validation checklist below. The application files in this handoff are unchanged.

### What is included and what is missing

| Included | Not supplied |
|---|---|
| Agent app, embedded admin, standalone admin, configuration, PDF.js license, illustrated guides | Current business manual and released knowledge pack |
| Browser-side import, review, export, routing, PDF rendering and local persistence | Unfinished review drafts from administrators' machines |
| Optional same-origin published-release loader | Azure environment, identity configuration, publication permissions and pipeline |
| Developer notes, source index, baseline checksums and optional embed-sync helper | Automated browser regression suite or evidence of production certification |

## 2. Architecture and boundaries

| Layer | Current implementation | Responsibility |
|---|---|---|
| Agent interface | index.html: markup, styles and script | Navigation, search, reader, favorites, context links and local release loading |
| Admin interface | knowledge-admin.html; identical base64 copy in index.html's embeddedAdmin script element | PDF import/comparison, mapping, source review, placement, routing, relationships and exports |
| PDF runtime | Bundled PDF.js main module, worker and binary assets in the admin HTML | PDF extraction and rendering; agent runtime obtains these assets from embeddedAdmin |
| Knowledge contract | agentos-knowledge-v1 JSON plus matching PDF | Reviewed procedures, page references, document identity, routes and relationships |
| Work-in-progress contract | agentos-admin-draft-v1 JSON | Resumable review state; not an agent release and not a substitute for the source PDF |
| Device persistence | IndexedDB, localStorage and limited sessionStorage paths | Browser-specific saved pair, favorites and preferences |
| Hosting | External static web host | Serve app/config/content; enforce authentication and protect downloads |

**Important coupling:** the agent reader decodes embeddedAdmin to obtain PDF.js and assets. Removing the embedded importer without providing a replacement asset loader can break PDF viewing even if the agent screen still opens.

Admin is loaded into an iframe using srcdoc. Parent/child functions coordinate review actions and applying a pack to the current tab. This is not a REST API. Applying a pack locally does not publish files to a server. The same-origin iframe relationship is part of the current design; isolating it onto another origin requires redesigning that communication.

The source is layered: later blocks replace or wrap earlier functions such as render, kLoad and receiveUrlContext. Search every assignment to a function before modifying it. The first definition is not necessarily the effective behavior.

### Content lifecycle

1. An administrator supplies a selectable-text manual PDF and, for updates, an earlier pack or PDF.
2. The importer extracts text and page information, matches configured headings and presents candidate procedures.
3. The administrator checks complete source pages, resolves page boundaries and placement, and records review decisions. Automated matching is not approval.
4. The administrator saves a draft for recovery and exports a reviewed knowledge pack for release.
5. The matching JSON/PDF pair is loaded locally or published by a deployment process outside this app.
6. The agent application validates the pair and displays original PDF pages. Search and routing use configured rules and text matching; no AI service is required by this package.

## 3. Where to make changes

Line references below describe the untouched v2.33 files. Use the symbol names as durable search anchors after editing. SOURCE-INDEX.md contains additional locations.

| Change | Start here | Notes |
|---|---|---|
| Colors, spacing, layout and responsive behavior | index.html style blocks and UI markup | Later CSS may override earlier rules. Test reader, sidebar and Admin at actual agent screen sizes. |
| Main categories and mapping defaults | NavigationGroups; BrowserGroups; CustomerNeeds | Related helpers also exist in admin. Keep export and display rules compatible. |
| Home tiles and shortcuts | homeDefinitions, homeShortcuts, renderHomeTiles, near lines 560–572 | Prefer pack settings for content-specific labels/order/visibility. |
| Agent search | readerResults, near line 542 | Validate real manual terminology and reviewed/unavailable filtering. |
| PDF viewer and internal links | LocalPdf, near line 495; readerToolbar and mountReader, near 550 | Preserve worker/assets, cancellation and document cleanup. |
| Related procedures | ArticleLinks; kArticleConditions | Relationships depend on valid reviewed sources and matching source signatures. |
| Favorites and remembered content | DeviceLibrary, near 625; restoreDevice, near 651; favorite helpers | Device storage is scoped by origin and application pathname. |
| Incoming intent/campaign/utterance | IntentRouting; intentInputs and applyIntentInputs, near 578–582 | Edit configured routes in Admin for routine business changes. |
| Direct article links | openLinkedSubject, near 710 | subjectId is a permanent procedure ID, not a heading or PDF page number. |
| Hosted release loading | refreshPublishedRelease, near 733; flightdeck-config.json | Enforces same-origin file paths for this published-pair workflow. |
| Admin tabs and embedded importer | showAdminWorkspace, selectAdminTab, receiveAdminPack, near 671–676 | Changes to standalone admin must also be embedded in index.html. |
| Import/extraction/matching | knowledge-admin.html: readDocumentFile, KnowledgeCore, reviewCandidate | Preserve fingerprint and review invalidation behavior. |
| Review screen and mapping edits | renderReview, renderMappingEditor, reviewVisibleMappings | Distinguish candidate detection from human approval. |
| Draft recovery | draftSnapshot, validateDraft, near admin line 297 | Keep compatibility with existing drafts; document migrations. |
| Export and release eligibility | exportPack onclick handler; refreshDemoControls | Do not bypass reviewed/unavailable and placement checks to enable export. |
| Admin route editor | adminRoutes, exportIntentRoutes, saveIntent | Unsaved route edits must be saved/discarded before export. |
| Reviewer name and preview preferences | currentReviewerName, saveReviewer, AdminPdfPreview | Reviewer text is self-entered metadata, not authenticated identity. |

For ordinary changes to article labels, placement, search phrases, home shortcuts, relationships or intent routes, use Admin and export a new pack. Do not hard-code each manual update into the application.

## 4. Data contracts and persistence

The released pack includes document metadata (including SHA-256 and page count), procedures, and optional routing/relationship data. Procedures use permanent IDs and carry source/review information and navigation fields. Treat KnowledgeCore.validate, IntentRouting.validate and ArticleLinks.validate as the current executable contract; this document is not a full replacement schema.

Preserve procedure IDs across releases. Favorites, incoming subjectId links, relationships and route destinations depend on them. A renamed heading does not require a new procedure ID. If an ID is retired, test the unavailable-link recovery path.

| Storage | Current behavior | Migration implication |
|---|---|---|
| IndexedDB flightdeck-device-v1, store saved | Saved JSON/PDF pair and favorites; keys use location.pathname and pathname + :favorites | A new origin or pathname can appear to lose remembered content. Export backups before migration. |
| localStorage | Preview preferences and optional remembered reviewer name | Per browser profile/origin; not central configuration or identity. |
| sessionStorage | kPersist contains a session pack path | A session pack alone does not provide the required matching PDF. |
| Downloaded review draft | Resumable admin state | Keep its exact source PDF; browser session state is not a backup. |
| Published files | Configured JSON/PDF served by the host | There is no browser-to-server save/publish API in this build. |

DeviceLibrary validates the PDF hash against the pack. Published loading also checks page count and readable procedure bounds. These integrity checks establish a matching pair; they are not a digital signature proving publisher authorization.

## 5. Published releases and startup behavior

The supplied configuration is disabled. To enable shared content, publish the real reviewed pair and set enabled to true. For example:

```json
{
  "enabled": true,
  "packUrl": "releases/2026-10-30/knowledge.json",
  "manualUrl": "releases/2026-10-30/manual.pdf"
}
```

Paths are relative to the fetched configuration location and must resolve to the application's origin. A separate storage hostname will be rejected by this loader even if CORS allows it. If using external object storage, provide a same-origin delivery route or deliberately redesign and validate this restriction.

The loader skips file:// use, tolerates a missing configuration file, and does nothing when enabled is not true. Requests use same-origin credentials, no-store and reject redirects. Authenticate through the main site before loading protected files; a sign-in page returned instead of JSON/PDF is not valid content.

Current limits include a 30-second abort timer for a published refresh, a 30,000,000-byte JSON limit and a 150,000,000-byte PDF limit. These are code limits, not proven performance targets. Test large manuals over the intended network and agent hardware.

Startup schedules restoreDevice first, then refreshPublishedRelease through Promise.resolve(deviceStartup).then(refreshPublishedRelease). With enabled configuration, a valid published pair can therefore replace a restored local pair at startup. During use, the refresh button explicitly requests another load; there is no periodic polling in this loader. A refreshed pair is not automatically a newly remembered device copy. Validate the desired behavior for existing saved users, fresh users and offline failures rather than assuming every agent instantly receives a new release.

Publish an immutable versioned pair first; update the configuration last through an atomic deployment process. Roll back the configuration and application together when required. Preserve the old pair until rollback is no longer needed. Do not overwrite only the PDF at an active release path.

## 6. Development and packaging workflow

1. Commit the untouched application as the v2.33 baseline. BASELINE-SHA256.txt identifies each original file.
2. Serve application/flightdeck-v2.33 as the web root with your normal local static-server tooling. Test over localhost and ultimately HTTPS; do not use file:// to test published loading.
3. Import a real test pack and its matching PDF through Knowledge. Keep business manuals and drafts in approved storage rather than casually adding them to a code repository.
4. Make a small change. For admin edits, edit knowledge-admin.html and regenerate embeddedAdmin using the optional helper in tools/.
5. Re-run the relevant acceptance cases and inspect browser console/network errors. Test both embedded and standalone Admin when changing shared logic.
6. Commit code, configuration templates, dependency/license information and release notes. Deploy through the team's chosen pipeline.

The optional sync helper uses Python 3 only on a developer machine. The application itself does not require Python. From this handoff folder:

```bash
python tools/sync_embedded_admin.py application/flightdeck-v2.33
python tools/sync_embedded_admin.py application/flightdeck-v2.33 --check
```

It updates only the embeddedAdmin payload. It does not synchronize duplicated helper functions outside that payload. It is a bridge for the current package, not a complete build system.

### Suggested later source organization

| Proposed area | Purpose |
|---|---|
| src/agent | Agent HTML templates, styles, navigation, reader and state |
| src/admin | Import, review, mapping, routing editor and export |
| src/shared | Knowledge schema validation, routing, relationships and navigation helpers |
| vendor/pdfjs | Versioned PDF engine, worker, fonts, CMaps/WASM and licenses |
| public | Runtime configuration and static public assets |
| scripts | Build, embedding and validation commands |
| tests | Schema fixtures and browser workflows |
| deploy | Container/web-server configuration and pipeline definitions |

This is a proposed refactor, not the current file layout. Generate deployable artifacts from one source of truth. A framework migration is optional and should be justified by maintainability needs, not by Azure hosting alone.

## 7. Findings to address during ownership transfer

**Confirmed by static inspection:**

- The embedded admin payload is byte-for-byte identical to knowledge-admin.html in this supplied package. Preserve that invariant until the architecture changes.
- Agent PDF rendering extracts PDF.js assets from the embedded admin. Separate the vendor asset boundary before removing the embed.
- Old fictional-account/demo functions and formatting-related code remain in source even though the v2.33 interface retires authored guidance and reports. Map reachability and remove dead code incrementally; do not infer that every surviving demo function is visible in the current UI.
- draftSnapshot still writes appVersion '2.29'. Separate application version metadata from schema versions; update deliberately and verify old-draft compatibility.
- There are multiple layers of function wrappers and repeated helper definitions. Consolidating these will reduce the risk of editing an inactive or subsequently overridden function.
- Authentication, server-authorized publishing and trusted reviewer identity are not implemented by this client. A user-entered reviewer name cannot serve as a server audit identity.
- The release notes remove reports, ratings and usage collection. Do not promise team reporting from this version. Adding it would be a separate feature.

**Implementation decisions still needed:** choose hosting/container model, identity integration, agent/admin/publisher permissions, manual storage and release ownership, cache/freshness policy, backup/rollback retention, and whether favorites must follow users between devices. These are not resolved by repackaging HTML.

## 8. Implementation boundaries and security review

Protect the application, configuration and content files with the intended host authentication. Protect any future upload/publish endpoint on the server and authorize the action there. The current Admin button and adminAccessEnabled variable are not security controls. If administrators alone should receive importer code, split the delivery architecture and preserve the PDF runtime separately.

The current application creates blob URLs for script modules, workers and PDFs, uses inline scripts/styles and embeds an iframe via srcdoc. Validate the hosting Content Security Policy against these behaviors; a restrictive policy can break the app. Derive a tested policy from actual runtime behavior rather than adding broad exceptions blindly.

Keep borrower information out of context URLs and sample/test files. Protect manually downloaded packs, PDFs and drafts according to company handling requirements. Validate hostile or malformed pack fields, escaped output and file-size handling as part of security review. The existing validation is useful but is not a completed security assessment.

Five9/Agent Workspace integration is URL-driven in this package. Use subjectId for an exact permanent ID; Intent (legacy intent is supported), OBCampaignName and IBUtterance provide configured route context. The containing Agent Workspace owns popout lifecycle and disposition cleanup. FlightDeck is not a Five9 call-control service or an MSP integration.

## 9. Acceptance checklist before release

| Scenario | Expected result |
|---|---|
| Fresh browser with configured reviewed pair | Valid content loads without workstation import; original pages render. |
| Existing saved pair and favorites | Restore succeeds at the intended address; release-update policy behaves as documented. |
| Disabled/missing config | Manual import remains usable; no false claim that central content loaded. |
| Wrong PDF, malformed pack or out-of-range pages | Invalid pair is rejected; previously usable content remains recoverable. |
| Expired sign-in, denied file, redirect, timeout | Clear failure/recovery; no sign-in HTML treated as content. |
| Explicit refresh while content is open | Complete valid pair replaces content; failure does not silently corrupt active state. |
| Import and changed-manual comparison | Accurate full-page boundaries, tables and images; changed sources require appropriate review. |
| Draft save, close and resume | Work resumes with matching source; wrong source is rejected. |
| Export with pending review/placement or unsaved route edit | Export is blocked until the required decisions are resolved. |
| Search, categories, shortcuts and related links | Only eligible procedures are offered; links reach the intended original pages. |
| Valid, invalid and retired subjectId | Correct article opens or a usable recovery message appears. |
| Intent, campaign, utterance and overlapping routes | Configured primary/choices behave correctly; unmatched context allows browsing. |
| Reader interaction | Zoom, internal PDF links, page navigation, preview and back behavior work without stale renders. |
| Embedded versus standalone Admin | Same export/review behavior after an admin change. |
| Permissions | Signed-out users cannot retrieve protected content; publisher authorization is enforced outside client UI. |
| Real deployment conditions | Edge/Chrome, target screen sizes, largest manual, slow network and constrained device memory are tested. |
| Rollback | Previous app/config/pair restores successfully and direct links remain meaningful. |

Record browser version, application commit, content release, manual hash, test result and remaining issues. Assign acceptance of business content to the content owner and hosting/security readiness to the implementing team.

## 10. Handoff verification and limits

This handoff is based on source inspection, configuration/release-note review, embedded-admin equality verification and file inventory. No application behavior was changed. The notes are not evidence of a live Azure deployment, end-to-end browser validation, vulnerability scan or business-content approval. No actual released manual/pack pair was supplied for those checks.

Recommended first milestones: reproduce baseline → establish repeatable packaging → test protected hosting and shared release loading → complete agreed final UI changes → execute acceptance and rollback tests → transfer release ownership. Keep the content and application release processes explicit so routine manual changes do not require code changes.
