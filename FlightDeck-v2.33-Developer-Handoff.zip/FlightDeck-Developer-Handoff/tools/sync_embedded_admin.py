#!/usr/bin/env python3
"""Synchronize the v2.33 embedded admin; does not modify shared outer helpers."""
import argparse
import base64
import re
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('app_directory', type=Path)
parser.add_argument('--check', action='store_true')
args = parser.parse_args()
index = args.app_directory / 'index.html'
admin = args.app_directory / 'knowledge-admin.html'
source = index.read_bytes()
pattern = re.compile(rb'(<script\b[^>]*\bid="embeddedAdmin"[^>]*>)(.*?)(</script>)', re.S)
matches = list(pattern.finditer(source))
if len(matches) != 1:
    raise SystemExit('Expected exactly one embeddedAdmin script; no files changed.')
match = matches[0]
payload = admin.read_bytes()
try:
    existing = base64.b64decode(re.sub(rb'\s+', b'', match[2]), validate=True)
except ValueError:
    raise SystemExit('Existing embeddedAdmin is not valid base64; no files changed.')
if existing == payload:
    print('OK: embedded and standalone admin match.')
elif args.check:
    raise SystemExit('Mismatch: run without --check after reviewing standalone admin edits.')
else:
    updated = source[:match.start(2)] + base64.b64encode(payload) + source[match.end(2):]
    index.write_bytes(updated)
    print('Updated embeddedAdmin. Test agent PDF rendering and both admin entry points.')
