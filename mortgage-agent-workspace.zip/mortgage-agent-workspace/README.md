# Mortgage Agent Workspace · local prototype

A React/Vite starter for a mortgage servicing agent desktop. All borrower records are **fictional sample data**. The left panel supports an approved Five9 ADT+ adapter URL. Four demo buttons simulate distinct call paths; they do not place Five9 calls.

## Run locally

1. Install Node.js 20.19+ or 22.12+.
2. Run `npm install` from this folder.
3. Run `npm run dev` and open the local URL printed by Vite.
4. Use the four demo buttons in the ADT panel to preview inbound, callback, and outbound openings. Sample borrower records are `10482953` and `20591744`; top search is now a live Five9 Contact DB search and needs a permitted Agent REST session.

The ADT+ panel defaults to `https://app.five9.com/clients/integrations/adt.main.html`, so no URL setup is needed for this test domain. To use another adapter URL, set `VITE_FIVE9_ADAPTER_URL` in `.env.local` and restart Vite, or change it in Settings for the current session. The adapter's ability to sign in inside an iframe depends on your tenant configuration and browser policy.

## What is implemented

### FlightDeck integration (v0.8)

- FlightDeck v2.32 is bundled at `/flightdeck/index.html`. Open Admin → Integrations to set a different permanent HTTPS URL and map app tasks to a reviewed FlightDeck subject ID or an intent. These settings are browser-local for the POC.
- Home and call task shortcuts open FlightDeck in a separate tab; exact subject ID takes priority, then configured intent and safe recognized call context. No loan number, customer name, raw freeform utterance, or authentication details are sent in the URL.
- FlightDeck validates direct subject links against the loaded readable release. Its existing Intent, OBCampaignName and IBUtterance routing remains. At the bundled address, load and remember the knowledge pack plus matching PDF in that browser profile; the package does not include a production manual.
- FlightDeck is the detailed procedure reader. Identity controls and brief task prompts remain in the call workspace.

### Home, Knowledge, and opening (v0.7)

- Agent Home is the idle landing page for voice and non-voice work. Search Five9 Contact DB, reopen local work from the last 24 hours, open fictional loan previews, and browse configured procedures and scripts without an active call. A new call takes the opening to the front. Reopening an item does not restore a Five9 call or independently verify identity.
- The first call screen combines Clara handoff, borrower/co-borrower selection, and conditional manual authentication or third-party authority. There is no extra verification page for the common authenticated Clara path.
- The header toggles light/dark appearance, saved in this browser. The embedded Five9 ADT is controlled by Five9 and does not inherit the app theme.
- Recent work is browser-local and limited to 24 hours and 30 entries; it includes contact names and loan identifiers. Before production, use an approved retention and security model. Lookup workspaces show servicing placeholders and unverified identity until a call begins.

### Live contact workspace and call synchronization (v0.6)

- A verified live Five9 contact now uses the same Resolution, Overview, Payments, Escrow, Insurance, History, Products and guided-task screens as the fictional loans. Every servicing field without a connection displays `Awaiting data connection`; values from the two samples appear only after an explicit preview selection, with a return button.
- The opening records `Verified borrower` or `Verified co-borrower` in one action after the applicable checks. `Someone else answered` branches to authority or message-only handling. A second loan requires a new loan-authority confirmation; verified caller identity can carry forward in the current call. The result is agent-recorded in browser memory, not a trusted authentication receipt.
- One sticky call strip contains state and actions above the workspace. Five9 CRM `callFinished` marks voice end without opening the Finish panel. A matching Agent WebSocket terminal event (5/31) closes the workspace whether disposition was submitted in ADT or in the app; other observed state values update the control strip. If the event feed is unavailable, a locally dismissible wrap-up remains, and the agent must confirm ADT closeout. An embedded cross-origin ADT cannot itself be read to detect its disposition.
- The Finish panel is opened only by the agent. Live API actions still require a permitted Five9 Agent REST session; an HTTP success may precede the corresponding event and may not prove that all downstream Five9 steps completed.

### Live Five9 POC and Admin scripting (v0.5)

- A live call now stays in a Five9 contact workspace even when its `LoanNumber` does not match the two fictional sample loans. Select a candidate, perform the agent-recorded verification steps, then view call/contact/campaign/client identity and explicit placeholders for unavailable servicing balances and dates. Call controls remain available. Verification is local to this session and is **not** independent authentication or a servicing-system record.
- After agent-recorded verification, optional buttons preview either fictional sample loan. A prominent banner marks the data as unrelated to the Five9 contact and returns to the live-contact view. No Five9 contact is re-associated.
- Admin → Fields maps stable script placeholders to CRM/contact or CAV fields for a domain, with a fallback and optional post-verification restriction. Admin → Scripts inserts placeholders and previews values present, missing, and before/after verification. Unknown placeholders block publishing in the local demo.
- Admin → Clients defines private-label spoken names matched to a trusted Five9 field, campaign name, or loan prefix. Exactly one match is required; otherwise the opening uses a neutral business name. A domain-specific client definition is stored locally until shared configuration is connected.
- Five9 CAV and CRM fields retain their source tags in the call observer. No sensitive values are persisted in browser Admin configuration. Live Five9 API permissions and the eventual servicing loan endpoint still determine what real data can be displayed or submitted.

### Current experience (v0.4)

- **Agent / Admin** navigation. Admin can manage local demo users, define roles and permissions, assign a physical servicing site, select the states approved for that site, edit and export wording (CSV/JSON), preview dynamic scripts, and configure client originations and the Five9 REST base URL. This browser-local configuration demonstrates the admin experience; it is not shared between machines and is not production authorization. Replace with Entra identity, a shared configuration service, role enforcement on the server, and change history before multi-site use.
- A demo call opens with Clara's reason and authentication status, followed by a client greeting and caller identification. An authenticated Clara result proceeds to agent verification. Unknown or unauthenticated results require manual authentication first. A different caller requires manual authentication and authority confirmation. These confirmation buttons are **simulation controls for fictional records only**.
- After demo verification, site coverage is evaluated against the property's state. If the site is not configured for that state, or site/state is unknown, servicing content stays unavailable and an approved transfer preview appears. The local demo site starts with NC approved so both fictional NC loans can be explored.
- A compact snapshot on Resolution shows total due, next due, last posted payment amount/date, and regular payment. Guided tasks and one Finish call panel replace duplicate outcome entry.
- A bottom daily metrics strip counts calls completed through the existing Five9 CRM SDK screen pop even when Agent REST metadata is unavailable. If the separate Agent WebSocket connects, it updates averages with Five9 handle, talk and wrap-up milliseconds. Calls are deduplicated by ID and grouped by original inbound/outbound direction, agent, domain and Eastern day. The ledger persists in this browser across refreshes when an agent ID is provided; when the SDK omits agent ID, it is scoped to this browser tab session. There are no RTS requests or gamification subscriptions. Demo calls and their illustrative durations remain separate; the strip shows connection status directly below the figures. Five9 agreement pricing for Agent REST/WebSocket is not specified in the supplied documentation.
- On Five9 inbound and outbound call events, the app attempts a read-only Five9 Contact DB lookup if a permitted REST base URL is configured. Inbound searches phone across Number1/Number2/Number3 first; outbound checks the contacts linked to that call when agent ID is provided; LoanNumber is the fallback. Multiple results remain candidates, never verification. The app continues using the existing read-only CRM SDK screen pop if REST access is unavailable.

To review locally, try each of the four named demo buttons; outbound uses an admin-managed campaign purpose and callback uses its own opening. After completing the fictional-data demo checks, open **Admin → Sites** and uncheck NC for the demo site; start another demo call to see the servicing exception. Edit **Admin → Scripts → Clara opening** and publish in the demo, then start a new call to preview the wording. Admin is visible for the seeded demo administrator; its own administrator role cannot be disabled through the UI.

The Five9 reference describes `GET /orgs/{orgId}/contact_fields`, `GET /orgs/{orgId}/contacts`, and `GET /agents/{agentId}/interactions/calls/{callId}/contacts`. Live lookup requires a numeric domain ID, Agent REST permissions, a compatible authenticated browser session, and an approved API origin. ADT iframe sign-in does not automatically authenticate the parent React page for Agent REST. Do not place passwords or tokens in the browser or `.env.local`.

### Contact search, call controls, and administration (v0.4)

- Top search queries Five9 Contact DB by `LoanNumber` or phone. Phone search uses a generic match and, if needed, explicit Number1/Number2/Number3 checks. Configure the numeric domain ID under **Admin → Integrations** to search before a call; a live call can supply its domain. Five9 Agent REST browser authentication, permission `CAN_PERFORM_CONTACT_LOOKUP`, and permitted CORS are required. A Five9 contact is **not** a servicing loan record: if its LoanNumber matches one of two fictional samples, the UI can preview that sample; otherwise it shows a candidate without inventing loan amounts.
- Selecting a contact changes only this workspace. The call stays active and the app asks for a fresh authority check before showing sample loan details. Multiple candidates from a phone search remain available in the loan switcher. It never writes the active Five9 call contact.
- Demo buttons model inbound with Clara authentication, inbound with manual authentication, queue callback, and outbound campaign. Admin manages approved script text and outbound purpose by domain/campaign. Existing saved scripts are retained when new default scripts are added.
- The compact call bar opens Answer, Hold/Resume, approved Transfer and Conference drawers, and Finish call. **Admin → Call controls** configures allowed destination IDs and task/call-type targeting; **Admin → Closeout** maps Five9 disposition IDs to recommendations and required work. Real dispositions are fetched from Five9 per campaign. Agent REST can submit answer/hold/disconnect, skill/agent/campaign transfers, skill/agent/campaign conferences, and disposition when the live agent session, call ID, domain ID, permissions, and browser origin permit it. A successful response is surfaced; failures leave ADT+ available. External transfers are disabled until the required DNC handling is connected.
- End voice call and submit disposition are distinct. When a note or follow-up owner is required, the current prototype collects a local draft but blocks a live disposition until an approved servicing write service can persist it. Demo actions never contact Five9.

### Test the live daily metrics

1. Keep ADT+ signed in and confirm the CRM SDK screen pop appears on a test call. The metrics strip now displays its connection status without opening Details. If its status says **Waiting for Five9 call** or **Call counts via CRM**, it can count SDK call completion events but cannot yet guarantee timing averages.
2. For full timing, in **Admin → Integrations**, enter the approved Five9 Agent REST base URL ending in `/appsvcs/rs/svc`, then save. If no REST URL is set, the app also tries the approved ADT+ URL's host. It requests Agent REST metadata to discover the active API host, then opens one WebSocket to `wss://<active-host>/appsvcs/ws/<unique-key>`; it sends a ping every 20 seconds. If metadata is blocked, it tries the configured URL host for the WebSocket, but that host may differ from the active API host. Browser session and origin settings can prevent either connection. Five9 allows up to three WebSockets per agent session.
3. Take an authorized inbound and outbound test call and end them in ADT+. Counts advance on CRM SDK call completion, or after `EVENT_CALL_DELETED` (5/31) when the WebSocket sees the call; averages appear only when actual Five9 timing fields are available. A transferred call remains under its original direction. Compare the figures against Five9 for the test calls before relying on them.

The WebSocket is an event feed, not a historical query. Calls missed while disconnected or in another browser are not recovered; an unexpected browser shutdown before the disposition event also leaves that call uncounted. The strip labels the source and connection status. Browser local storage retains call IDs and timing (no borrower names or numbers); use a managed browser profile and organizational retention controls for production.

The metrics Details panel shows counts of observed call events and events with positive timing values. Timing already cleared by an older build cannot be reconstructed from its saved ledger; take one new test call after updating to check the corrected timing merge.

- Fixed left ADT region, call context bar, borrower search, and inbound/outbound demo screen pops.
- Guided task screen with contact verification, payment, escrow, new-to-servicing and product-interest walkthroughs. Common task steps also appear inline on Resolution. Wording is illustrative and should be reviewed by the appropriate owners before real use.
- Compact **Call Resolution** screen is the default on a screen pop. It combines call context, immediate answer, relevant facts, suggested words, next actions, and closeout. It suggests a task from a mapped Five9 call-reason field; agents can change tasks in one click. The first two designed examples are New to Servicing and Why Payment Changed. Its document, draft, payment, and tracing actions are **previews only** and perform no transaction or email delivery.
- A call now opens with Clara's handoff and a greeting; Clara/IVR authentication is shown separately from the agent's verification. Loan details remain hidden for an active call until the fictional-data demo verification control is selected. The demo control **does not authenticate a real person**. A failed result leaves protected content hidden.
- You do not need a live Five9 call to preview the opening and verification: click **Preview inbound call** in the workspace or **Inbound/Outbound** under Local Screen Pop Test in the ADT panel. Authentication is no longer a “Mark reviewed” checklist in Guided Work.
- A persistent Back to call button returns from loan sections and guides to the selected call task. The task remains selected when returning. Originations transfer opens the same call-control drawer as other transfers; a configured Five9 skill or campaign may execute when an authenticated Agent REST session is available. Lead delivery remains a preview only.
- Settings includes per-domain, browser-local client originations destination fields. They are configuration placeholders and are not sufficient to enable live call controls.
- Overview, payments, expanded escrow field map, insurance, assistance, optional products, history, and knowledge screens.
- Alert and summary cards; sample borrower records and recent history.
- Strict same-origin `postMessage` demo event `MORTGAGE_WORKSPACE_DEMO_POP` with `{direction: 'inbound'|'outbound', loanId: '10482953'}`. This is **not** a Five9 event contract.
- Read-only Five9 CRM SDK observer: listens for call start/accept/finish and reads call attached variables and VCC contact fields. An unmatched call hides the sample borrower panel. No Five9 data is written.
- Domain setup discovers field names on a test call. Choose the identifier, authentication, call reason, handoff, special handling, and originations fields for that domain. Field-name mappings are stored locally by Five9 domain ID; call values are not persisted. `LoanNumber` is suggested when present, but any permitted field can be selected.
- Export/import the field-name mappings as JSON to carry configurations between workstations. The export excludes adapter URLs, test identifier values, and call data. In production, distribute approved mappings centrally with versioning and access control.
- Live call context panel displays only fields selected by the domain setup. It treats those fields as context, not as authorization to disclose or transact.

## Test a real Five9 screen pop and preview sample data

1. Keep the ADT+ URL that already worked for your login. Confirm with your Five9 administrator that the URL supports the CRM API (Five9's integration tutorial uses `f9crmapi=true`). This app loads Five9's official CRM SDK from its CDN.
2. Place an authorized test inbound or outbound call. The workspace should display **Five9 call received** even when no loan field matches.
3. Open **Settings** after a test call. Select the identifier field for the current Five9 domain from the discovered names, then optionally select context fields. Save setup. The browser keeps only this domain's **field names** locally.
4. Complete caller verification. The live contact opens the full workspace with placeholders for disconnected servicing fields. Use **Preview sample 10482953** or **Preview sample 20591744** in the live-contact banner to explore populated fictional data, then return to the Five9 contact. If the loan identifier is empty, check whether your campaign or IVR supplies it.

The adapter may require additional configuration to expose CRM SDK events to the parent page. The app does not register CRM save callbacks. Authorized Agent REST actions may change Five9 call state or submit a disposition when their controls are used. It never uses ANI alone to authorize a borrower.

The next data integration is specified in `docs/loan-lookup-contract.md`. Provide a redacted FV4 or backend response shape and an approved read-only lookup route before wiring real borrower fields.

The Five9 Agent and Supervisor REST API reference supplied for this project documents transfers to a skill, campaign, external number, speed dial or agent and warm transfer completion/cancellation. To execute an originations transfer, establish an authenticated Agent REST session, confirm transfer permissions and approved destination IDs, and correlate the active call ID with the CRM SDK screen pop. Keep the actual verification result, lead delivery and any servicing transaction tied to approved services; the React demo does not perform these operations.

## Live integration contract to complete

1. Confirm your Five9 product/tenant supports the CRM SDK and embedded ADT+ adapter, and obtain its official integration guide, adapter URL, configuration, browser and origin requirements, and test agent.
2. Wire the documented CRM SDK initialization and call lifecycle callbacks in a dedicated integration module. Map inbound ANI / IVR-authenticated loan number / Five9 contact variables and outbound dial record / call ID. Handle transfers, consults, multiple matches, no match, and call end.
3. Add a backend lookup service. Do not expose MSP/MWS credentials, Five9 service secrets, or private APIs from React. Return only fields the authorized agent needs, and audit access.
4. Replace sample data with borrower and loan APIs. Determine the system of record and write permissions for notes, payments, draft changes, escrow, insurance, and assistance. Never assume an IVR identification is sufficient authorization for account disclosure.
5. Add Entra SSO and role-based access before using actual borrower data. Review CSP, frame, microphone, cookie, and network policy for localhost and your eventual hosted origin.

## Inputs that unblock the live proof of concept

- Five9 region, ADT product/version, CRM SDK documentation and adapter URL for your tenant; whether the existing FV4 script tab already uses ADT+.
- One sanitized inbound event and one outbound event, including call ID, campaign, contact variables, ANI/DNIS, IVR authentication result, and loan identifier where present.
- Dev or test borrower lookup API contract, authentication method, and redacted response. A working FV4 data mapping is ideal.
- Preferred initial workflows and which actions are read-only versus executable.
- Approved authentication, contact verification, payment authorization, escrow explanation, referral, and optional product scripts, including version owners and conditional rules.

## Updating an existing local copy

Close the development server with Ctrl+C. Extract the new ZIP to a new folder, then copy your existing `.env.local` file into the new `mortgage-agent-workspace` folder if you used one for the adapter URL. Run `npm install` and `npm run dev` from the new folder. The adapter URL entered only through Settings is temporary and must be entered again. Never copy `node_modules` or actual borrower data into the new folder.

Do not put production PII, passwords, access tokens, or service credentials in `.env.local` or the browser console.
