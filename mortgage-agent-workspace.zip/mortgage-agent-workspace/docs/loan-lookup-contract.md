# Read-only borrower lookup: next integration boundary

The Five9 CRM SDK already provides the active `interactionId` and `LoanNumber`. The browser currently matches that loan number to a fictional test profile. To show actual test borrower data, supply an approved read-only endpoint and a redacted response. Do not put credentials or service secrets in this React app.

## Suggested endpoint

`GET /api/loans/{loanNumber}/agent-summary`

The backend should authenticate the agent, authorize access, perform the system-of-record lookup, return only approved fields, and audit the request. Production can serve the frontend and API from the same protected origin. Do not use ANI as proof of identity. A Five9 `Authenticated` call variable is context; confirm its meaning and freshness before using it as a control.

## Suggested response shape (fictional example)

```json
{
  "loanNumber": "10482953",
  "borrowers": [{"displayName": "Jordan Ellis", "role": "Primary"}],
  "property": {"city": "Wilmington", "state": "NC"},
  "loan": {"status": "Current", "unpaidPrincipal": 286430.18, "interestRate": 5.625},
  "payment": {"amountDue": 2148.72, "dueDate": "2026-10-01", "lastPostedDate": "2026-09-03", "pendingDraft": null},
  "escrow": {"balance": 3472.19, "shortage": 612, "analysisDate": "2026-08-28"},
  "alerts": [{"type": "escrow-analysis", "summary": "New payment effective November 1"}]
}
```

This is a proposed UI contract, not a claim about existing FV4 or MSP field names. A redacted real response or endpoint specification is needed to map the actual payload. Handle 0, 1, and multiple loan matches explicitly; show an error or empty state rather than leaving the previous borrower's information on screen. Add write actions only after the read path is proven.
