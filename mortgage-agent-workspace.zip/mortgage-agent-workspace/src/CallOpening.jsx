import React,{useState} from 'react';
import {renderScript} from './workspaceConfig';
import {scriptValues} from './scriptFields';

export default function CallOpening({config,agent,loan,context,lookup,onVerify,onFail,onSelectCandidate,kind='inbound',campaignRule=null,reverify=false,contact=null,client=null,priorIdentity=''}){
 const [correctedReason,setCorrectedReason]=useState('');
 const [manualDone,setManualDone]=useState(false);
 const [otherOpen,setOtherOpen]=useState(false);
 const [otherAuthorityDone,setOtherAuthorityDone]=useState(false);
 const rawReason=kind==='outbound'?campaignRule?.purpose||'':context?.reason||'';
 const reason=correctedReason||rawReason;
 const auth=String(context?.authentication||'').toLowerCase();
 const authenticated=kind==='inbound'&&/^(yes|true|1|authenticated|success|passed|verified)$/.test(auth);
 const manualRequired=kind==='inbound'&&(!authenticated||otherOpen)&&!priorIdentity;
 const ready=!manualRequired||manualDone;
 const vars=scriptValues(config,{agent,contact:contact||(loan?{name:loan.name,loanNumber:loan.id}:null),context,reason,client});
 const scriptId=kind==='outbound'?'outbound-opening':kind==='callback'?'callback-opening':reason?'opening':'opening-fallback';
 const coName=context?.coBorrowerName||context?.fields?.find(f=>/^(co.?borrower.?name|co.?borrower.?full.?name)$/i.test(f.name))?.value;
 const label=kind==='outbound'?'OUTBOUND · CUSTOMER CONFIRMATION':kind==='callback'?'QUEUE CALLBACK · CUSTOMER CONFIRMATION':'INBOUND · CLARA HANDOFF + IDENTITY';
 return <section className="opening card openingSingle">
  <div className="openingHead"><span className="required">FIRST · {label}</span><span className="openingProgress">Greeting and verification · one screen</span></div>
  <h2>{reverify?'Confirm authority for this loan':'Open the call and identify who answered'}</h2>
  <div className="handoffFacts"><div><small>{kind==='outbound'?'CAMPAIGN PURPOSE':kind==='callback'?'CALLBACK REASON':'CLARA REASON'}</small><strong>{rawReason||(kind==='outbound'?'Unmapped campaign · ask after confirming the person':'No reason received — ask the caller')}</strong></div><div><small>{kind==='inbound'?'CLARA AUTHENTICATION':'CALLER VERIFICATION'}</small><strong>{kind==='inbound'?context?.authentication||'Unknown · manual authentication required':'Confirm the person before discussing the purpose'}</strong></div><div><small>FIVE9 CONTACT LOOKUP</small><strong>{lookup.status==='matched'?'One candidate':lookup.status==='multiple'?'Multiple candidates':lookup.message||'Waiting for call context'}</strong></div></div>
  {lookup.candidates?.length>1&&<div className="candidateList"><b>Multiple contact candidates</b><span>Select the matching contact before recording verification. A contact match is not verification.</span>{lookup.candidates.slice(0,8).map(c=><button key={c.id} onClick={()=>onSelectCandidate(c)}>{c.name} · Loan {c.loanNumber||'unavailable'}</button>)}</div>}
  {!reverify&&<div className="openingScript"><small>OPENING · ADMIN MANAGED WORDING</small><p>“{renderScript(config,scriptId,vars)}”</p></div>}
  {kind==='inbound'&&!reverify&&<label className="inlineLabel">Correct Clara’s reason if needed<input value={correctedReason} onChange={e=>setCorrectedReason(e.target.value.slice(0,160))} placeholder="Correct reason, or leave blank"/></label>}
  {manualRequired&&<div className="guideNotice"><b>Manual authentication required.</b> Complete the approved process before marking a person verified. <button onClick={()=>setManualDone(v=>!v)}>{manualDone?'✓ Manual authentication completed':'Record manual authentication completed'}</button></div>}
  {reverify&&<div className="guideNotice"><b>Another loan selected.</b> Confirm this person's authority for this loan. {priorIdentity&&<button disabled={!ready} onClick={()=>onVerify(reason,priorIdentity)}>Confirm authority and continue as {priorIdentity}</button>}</div>}
  <div className="openingIdentity"><div><small>WHO IS SPEAKING?</small><p>Select only after the agent completes the required check. This records the agent's result in one action.</p></div><div className="openingActions"><button disabled={!ready} onClick={()=>onVerify(reason,'borrower')}>Verified borrower{contact?.name||loan?.name?` · ${contact?.name||loan.name}`:''}</button><button disabled={!ready} onClick={()=>onVerify(reason,'co-borrower')}>Verified co-borrower{coName?` · ${coName}`:''}</button><button className={otherOpen?'selected':''} onClick={()=>setOtherOpen(v=>!v)}>Someone else answered</button><button onClick={onFail}>Unable to verify</button></div></div>
  {otherOpen&&<div className="otherAnswerer"><b>Someone else answered</b><p>Determine whether the person has approved authority, is taking a message, or is the wrong contact. Do not disclose loan information until the applicable checks are complete.</p><div className="openingActions"><button onClick={()=>setOtherAuthorityDone(v=>!v)}>{otherAuthorityDone?'✓ Third-party authority confirmed':'Confirm third-party authority'}</button><button disabled={!ready||!otherAuthorityDone} onClick={()=>onVerify(reason,'authorized third party')}>Record verified authorized third party</button><button onClick={onFail}>Message only / wrong contact</button></div></div>}
  <p className="muted">Agent-recorded result for this call only. Five9 contact data is not authentication evidence or a servicing loan record.</p>
 </section>;
}
