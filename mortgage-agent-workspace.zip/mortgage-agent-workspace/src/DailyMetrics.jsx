import React,{useState} from 'react';
const easternDay=date=>new Intl.DateTimeFormat('en-CA',{timeZone:'America/New_York',year:'numeric',month:'2-digit',day:'2-digit'}).format(date);
const duration=seconds=>Number.isFinite(seconds)?`${Math.floor(seconds/60)}:${String(Math.round(seconds%60)).padStart(2,'0')}`:'—';
export default function DailyMetrics({activity,config,liveMetrics,metricsStatus,diagnostics}){
 const [expanded,setExpanded]=useState(false);
 const today=easternDay(new Date());
 const calls=activity.filter(item=>item.demo&&easternDay(new Date(item.started))===today);
 const inbound=calls.filter(c=>c.direction==='Inbound').length;
 const outbound=calls.filter(c=>c.direction==='Outbound').length;
 const avg=key=>{const n=calls.map(c=>c[key]).filter(Number.isFinite);return n.length?duration(n.reduce((sum,x)=>sum+x,0)/n.length):'—'};
 const shown=liveMetrics||{count:calls.length,inbound,outbound};
 const display=key=>liveMetrics?duration(liveMetrics[key]):avg(key);
 return <div className="dailyMetrics"><div className="metricsSummary"><span className="metricsName">MY DAY <small>Eastern · {liveMetrics?'Five9 observed calls':'demo only'}</small></span><span><b>{shown.count}</b> calls <small>{shown.inbound} in · {shown.outbound} out</small></span><span><b>{display('handle')}</b> avg handle</span><span><b>{display('talk')}</b> avg talk</span><span><b>{display('acw')}</b> avg ACW</span><button onClick={()=>setExpanded(x=>!x)} aria-expanded={expanded}>{expanded?'Hide':'Details'}</button></div><div className="metricsConnection" role="status">{metricsStatus}</div>{expanded&&<div className="metricsDetail">{config?.competitionEnabled&&<div className="competitionDemo"><b>Team goal: avg handle {duration(config.targetHandleSeconds)}</b><span>Competition standings require a separate team data source.</span></div>}Counts use CRM SDK call completion when received; precise timing requires Five9 WebSocket events. {liveMetrics?'Completed calls seen by this app and stored in this browser for this Five9 agent and Eastern day. Calls missed during an outage are not reconstructed.':'Demo calls and illustrative timing are separate from live Five9 activity.'} Transfers keep their original direction. {diagnostics&&<div className="metricDiagnostic">Events seen: {diagnostics.callEvents} · Completed events: {diagnostics.completedEvents} · Events with positive timing: {diagnostics.timingEvents} · Scope: {diagnostics.agentScope}. No caller data is shown here.</div>}</div>}</div>
}
