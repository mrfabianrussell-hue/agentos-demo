import React from 'react';
import {flightDeckUrl,TASKS} from './flightdeckLink';
export default function FlightDeckGateway({config,task='',context={},compact=false}){
 const selected=task||'paymentChange';
 const link=flightDeckUrl(config,selected,context);
 const label=TASKS.find(([id])=>id===selected)?.[1]||'Knowledge';
 return <section className={compact?'flightDeckCall card':'flightDeckGateway card'}><div><div className="eyebrow">FLIGHTDECK · PROCEDURES</div><h2>{compact?`Relevant procedure · ${label}`:'Knowledge & procedures'}</h2><p>{compact?'Open the reviewed procedure for this task. Confirm it applies to the customer.':'Search and review the current Flight Manual between calls. During a call, use the task shortcut to reach relevant guidance.'}</p></div><div className="flightDeckActions">{link?<a href={link} target="_blank" rel="noopener noreferrer">{compact?'Open relevant procedure ↗':'Open FlightDeck ↗'}</a>:<span>Configure a valid FlightDeck URL in Admin → Integrations.</span>}{!compact&&TASKS.slice(0,5).map(([id,name])=><a key={id} href={flightDeckUrl(config,id)||'#'} target="_blank" rel="noopener noreferrer">{name} ↗</a>)}</div><small>FlightDeck opens in a separate tab. No loan number or identity data is sent in the link.</small></section>;
}
