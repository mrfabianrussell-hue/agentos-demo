export const callKind=type=>String(type||'').toUpperCase()==='QUEUE_CALLBACK'?'callback':/^(INBOUND|INBOUND_)/i.test(type||'')?'inbound':'outbound';
export const campaignRule=(config,domainId,campaignId,campaignName)=>{
 const rules=config.campaignRules||[];
 return rules.find(rule=>rule.domainId===String(domainId||'')&&rule.campaignId&&rule.campaignId===String(campaignId||''))||rules.find(rule=>rule.domainId===String(domainId||'')&&rule.campaignName?.toLowerCase()===String(campaignName||'').toLowerCase())||null;
};
export const destinationsFor=(config,domainId,kind,task)=>((config.callDestinations||[]).filter(item=>item.enabled&&(!item.domainId||item.domainId===String(domainId||''))&&(!item.kind||item.kind===kind)&&(!item.task||item.task===task)));
export const closeoutRule=(config,dispositionId)=>((config.closeoutRules||[]).find(item=>item.dispositionId===dispositionId)||null);
