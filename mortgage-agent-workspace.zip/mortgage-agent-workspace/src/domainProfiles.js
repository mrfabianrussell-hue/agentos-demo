const KEY='mortgage-agent-domain-profiles-v1';
const allowed=['identifier','authentication','reason','handoff','specialHandling','originations','propertyState','coBorrowerName'];
export function loadProfiles(){try{return JSON.parse(localStorage.getItem(KEY)||'{}')}catch{return {}}}
export function saveProfile(domainId,profile){
  if(!domainId||['__proto__','constructor','prototype'].includes(String(domainId)))return;
  const clean=Object.fromEntries(allowed.map(key=>[key,/ssn|social.security|password|token/i.test(profile[key]||'')?'':String(profile[key]||'').slice(0,120)]));
  const all=loadProfiles();all[String(domainId)]=clean;
  localStorage.setItem(KEY,JSON.stringify(all));
  return all;
}
export function importProfiles(value){
  if(!value||typeof value!=='object'||Array.isArray(value))throw new Error('Invalid mapping file');
  const current=loadProfiles();
  for(const [domainId,profile] of Object.entries(value)){
    if(!/^[\w.-]{1,120}$/.test(domainId)||['__proto__','constructor','prototype'].includes(domainId)||!profile||typeof profile!=='object'||Array.isArray(profile))throw new Error('Invalid domain mapping');
    current[domainId]=Object.fromEntries(allowed.map(key=>{
      const field=profile[key]??'';
      if(typeof field!=='string'||field.length>120||/ssn|social.security|password|token/i.test(field))throw new Error('A field is not permitted');
      return [key,field];
    }));
  }
  localStorage.setItem(KEY,JSON.stringify(current));return current;
}
export function fieldValue(fields,name){
  if(!name||/ssn|social.security|password|token/i.test(name))return '';
  return String(fields?.find(field=>field.name===name&&String(field.value??'').trim())?.value??'').trim();
}
export const fieldRoles=[
  ['identifier','Loan identifier for screen pop'],
  ['authentication','Authentication status'],
  ['reason','Call reason or IVR task'],
  ['handoff','Assistant handoff guidance'],
  ['specialHandling','Special handling'],
  ['originations','Originations interest flag'],
  ['propertyState','Property state for site coverage'],
  ['coBorrowerName','Co-borrower name (if supplied)']
];
