const origin=base=>{try{const url=new URL(base);if(url.protocol!=='https:'||!/(^|\.)five9\.(com|net|eu)$/.test(url.hostname))return null;return `${url.origin}/appsvcs/rs/svc`}catch{return null}};
const route=(agentId,callId)=>`/agents/${encodeURIComponent(agentId)}/interactions/calls/${encodeURIComponent(callId)}`;
export async function five9Request(base,path,{method='GET',body,signal}={}){
 const root=origin(base);if(!root)throw Error('Configure a valid Five9 Agent REST HTTPS URL.');
 const response=await fetch(root+path,{method,credentials:'include',signal,headers:{Accept:'application/json',...(body?{'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{})});
 if(!response.ok)throw Error(`Five9 request failed (HTTP ${response.status}). Check your agent session and permissions.`);
 if(response.status===204)return null;const text=await response.text();try{return text?JSON.parse(text):null}catch{return text}
}
export async function dispositions(base,domainId,campaignId,{signal}={}){
 if(!/^\d+$/.test(String(domainId)))throw Error('Numeric Five9 domain ID is needed to load dispositions.');
 const path=campaignId?`/orgs/${encodeURIComponent(domainId)}/campaigns/${encodeURIComponent(campaignId)}/dispositions`:`/orgs/${encodeURIComponent(domainId)}/no_campaign_dispositions`;
 const response=await five9Request(base,path,{signal});
 const flat=[];const walk=(item)=>{if(!item||typeof item!=='object')return;if(Array.isArray(item)){item.forEach(walk);return}if(item.id&&item.name)flat.push({id:String(item.id),name:String(item.name),flags:item.flags||[]});for(const key of ['dispositions','children','groups','items','data','CALL'])if(item[key])walk(item[key])};walk(response);
 return [...new Map(flat.map(x=>[x.id,x])).values()];
}
export async function callAction(base,{agentId,callId,action,destination,dispositionId}){
 if(!agentId||!callId)throw Error('Five9 agent and call IDs are needed for call control.');
 const path=route(agentId,callId);
 if(['answer','hold','unhold','disconnect','complete_transfer','cancel_transfer'].includes(action))return five9Request(base,`${path}/${action}`,{method:'PUT'});
 if(action==='complete_warm_conference')return five9Request(base,`${path}/complete_warm_conference`,{method:'POST'});
 if(action==='dispose'){if(!dispositionId)throw Error('Choose an available Five9 disposition.');return five9Request(base,`${path}/dispose`,{method:'PUT',body:{dispositionId}})}
 if(action==='transfer'){
  if(!destination?.id)throw Error('Configure an approved transfer destination.');
  if(destination.type==='skill')return five9Request(base,`${path}/transfer_to_skill`,{method:'PUT',body:{skillIds:[destination.id],warm:!!destination.warm,timeout:30000,recordVoicemail:false}});
  if(destination.type==='agent')return five9Request(base,`${path}/transfer_to_agent`,{method:'PUT',body:{agentId:destination.id,warm:!!destination.warm,timeout:30000,recordVoicemail:false}});
  if(destination.type==='campaign')return five9Request(base,`${path}/transfer_to_campaign`,{method:'PUT',body:{campaignId:destination.id,warm:!!destination.warm}});
  throw Error('This destination type needs a confirmed Five9 request schema before live transfer.');
 }
 if(action==='conference'){
  if(destination?.type==='campaign'&&destination.id)return five9Request(base,`${path}/add_campaign_to_conference`,{method:'POST',body:{campaignId:destination.id,warm:!!destination.warm}});
  if(['agent','skill'].includes(destination?.type)&&destination.id)return five9Request(base,`${path}/add_${destination.type}_to_conference`,{method:'POST',body:{id:destination.id,warm:!!destination.warm,includeCallerInfo:false}});
  throw Error('Choose an approved agent, skill or campaign conference destination.');
 }
 throw Error('Unsupported live call action.');
}
