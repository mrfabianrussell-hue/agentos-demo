// Five9 Agent WebSocket event IDs 5 and 31 are terminal for the observed call.
// A CRM callFinished callback marks voice end, which can precede disposition.
export function observedCallEvent(event,activeCallId){
 const payload=event?.payLoad||event?.payload||{};
 const callId=String(payload.id||payload.callId||'');
 if(!callId||callId!==String(activeCallId||''))return {kind:'unrelated'};
 const eventId=String(event?.context?.eventId||'');
 if(eventId==='5'||eventId==='31')return {kind:'closed',callId};
 const state=String(payload.state||'').toUpperCase();
 if(!state)return {kind:'unchanged',callId};
 return {kind:'state',callId,state,voiceEnded:['WRAP_UP','WRAPUP','DISCONNECTED','ENDED'].includes(state)};
}
