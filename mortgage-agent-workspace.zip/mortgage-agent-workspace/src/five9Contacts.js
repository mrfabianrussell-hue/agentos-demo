const digits=value=>String(value||'').replace(/\D/g,'').replace(/^1(?=\d{10}$)/,'');
const value=(fields,key)=>String(fields?.find(f=>f.name.toLowerCase()===key.toLowerCase())?.value||'').trim();
const nameFrom=(contact,mapping,key)=>String(contact?.fields?.[mapping[key]]||'').trim();
function result(contacts,fields,source){
  const mapping=Object.fromEntries(fields.map(f=>[String(f.name).toLowerCase(),String(f.id)]));
  return {source,candidates:contacts.map(c=>({id:String(c.id||''),loanNumber:nameFrom(c,mapping,'loannumber'),name:[nameFrom(c,mapping,'first_name'),nameFrom(c,mapping,'last_name')].filter(Boolean).join(' ')||'Five9 contact',phones:['number1','number2','number3'].map(key=>nameFrom(c,mapping,key)).filter(Boolean)}))};
}
// Read-only Agent REST lookup. An embedded ADT session does not itself grant this page an API session.
export async function lookupFive9Contact({base,domainId,phone,loanNumber,direction,agentId,callId,signal}){
  if(!base||!/^https:\/\//i.test(base))return {status:'unavailable',message:'Configure a permitted HTTPS Five9 Agent REST base URL to enable contact lookup.'};
  if(!/^\d+$/.test(String(domainId||'')))return {status:'unavailable',message:'Numeric Five9 domain ID is required for Contact DB lookup.'};
  const root=base.replace(/\/$/,'');
  const get=async(path)=>{const response=await fetch(`${root}${path}`,{credentials:'include',signal,headers:{Accept:'application/json'}});if(!response.ok)throw new Error(`Five9 lookup returned HTTP ${response.status}`);return response.json()};
  try{
    const fields=await get(`/orgs/${encodeURIComponent(domainId)}/contact_fields`);
    const fieldList=Array.isArray(fields)?fields:fields?.data||[];
    if(!Array.isArray(fieldList))throw new Error('Five9 contact field metadata was not an array');
    const seen=new Map();
    const search=async(query)=>{const contacts=await get(`/orgs/${encodeURIComponent(domainId)}/contacts?_s=${encodeURIComponent(query)}`);for(const c of Array.isArray(contacts)?contacts:contacts?.contacts||contacts?.data||[])seen.set(String(c.id),c)};
    const normalized=digits(phone);
    if((direction==='Inbound'||direction==='Manual')&&normalized){
      // Documented generic number search covers system phone fields; fall back to explicit fields.
      await search(normalized);
      if(!seen.size)await Promise.all(['number1','number2','number3'].map(key=>search(`${key}==${normalized}`)));
    }
    if(direction==='Outbound'&&agentId&&callId){
      try{const linked=await get(`/agents/${encodeURIComponent(agentId)}/interactions/calls/${encodeURIComponent(callId)}/contacts`);for(const c of linked?.contacts||[])seen.set(String(c.id),c)}catch{/* Some outbound call types do not expose this endpoint. */}
    }
    if(direction==='Outbound'&&!seen.size&&loanNumber)await search(`LoanNumber==${loanNumber}`);
    if(!seen.size&&loanNumber)await search(`LoanNumber==${loanNumber}`);
    const found=result([...seen.values()],fieldList,'Five9 Contact DB');
    return {status:found.candidates.length===1?'matched':found.candidates.length>1?'multiple':'none',...found,message:found.candidates.length?`${found.candidates.length} contact candidate(s) found`:'No Five9 contact matched'};
  }catch(error){return {status:'unavailable',message:`Contact lookup unavailable: ${error.message}`}}
}
export function callLookupKeys(context,identifierField='LoanNumber'){return {phone:context?.ani||value(context?.fields,'ANI')||value(context?.fields,'number'),loanNumber:value(context?.fields,identifierField)||'',direction:context?.direction||'Inbound',agentId:context?.agentId,callId:context?.id}};
