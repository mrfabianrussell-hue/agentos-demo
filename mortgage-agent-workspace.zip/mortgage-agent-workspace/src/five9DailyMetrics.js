const PREFIX='mortgage-five9-daily-v1';
export const easternDay=date=>new Intl.DateTimeFormat('en-CA',{timeZone:'America/New_York',year:'numeric',month:'2-digit',day:'2-digit'}).format(date);
const ms=value=>value!==null&&value!==undefined&&value!==''&&Number.isFinite(Number(value))&&Number(value)>=0?Number(value):null;
export function callDirection(type){const t=String(type||'').toUpperCase();if(t.startsWith('INBOUND')||t==='QUEUE_CALLBACK')return 'Inbound';if(t.startsWith('OUTBOUND')||t==='AUTODIAL'||t==='AGENT_PREVIEW')return 'Outbound';return null}
export function summarizeCalls(calls){const rows=Object.values(calls||{}).filter(c=>c?.completed&&c.direction);const average=field=>{const values=rows.map(c=>c[field]).filter(Number.isFinite);return values.length?values.reduce((a,b)=>a+b,0)/values.length:null};return {count:rows.length,inbound:rows.filter(c=>c.direction==='Inbound').length,outbound:rows.filter(c=>c.direction==='Outbound').length,handle:average('handle'),talk:average('talk'),acw:average('acw')}}
export function createDailyLedger(storage,agentId,domainId,now=()=>new Date()){
 if(!agentId||!domainId)throw new Error('An agent and domain are required for daily metrics');
 const identity=`${PREFIX}:${encodeURIComponent(domainId)}:${encodeURIComponent(agentId)}`;
 const key=date=>`${identity}:${easternDay(date)}`;
 const read=date=>{try{const data=JSON.parse(storage.getItem(key(date))||'{}');return data&&typeof data==='object'&&!Array.isArray(data)?data:{}}catch{return {}}};
 const write=(date,data)=>{try{storage.setItem(key(date),JSON.stringify(data));return true}catch{return false}};
 const record=(eventId,payload,observedAt=now())=>{
  const id=String(payload?.id||'');if(!id||!['3','4','5','30','31'].includes(String(eventId)))return null;
  const eventDate=new Date(observedAt);const date=Number.isFinite(eventDate.getTime())?eventDate:now();
  const priorDay=payload.handleTimestamp?new Date(Number(payload.handleTimestamp)):date;
  const started=Number.isFinite(priorDay.getTime())&&priorDay.getFullYear()>2000?priorDay:date;
  const day=easternDay(started);const calls=read(started);const old=calls[id]||{};
  const direction=old.direction||callDirection(payload.callType);
  if(!direction)return null;
  // Event 5/31 removes a completed interaction after disposition. Repeated events never add a second call.
  const completed=old.completed||['5','31'].includes(String(eventId));
  const measure=(source,target)=>{const value=ms(payload[source]);return value===null?old[target]??null:value/1000};
  calls[id]={direction,started:old.started||started.toISOString(),completed,handle:measure('handleTime','handle'),talk:measure('talkTime','talk'),acw:measure('wrapupTime','acw')};
  const saved=write(started,calls);
  return {day,summary:summarizeCalls(calls),saved};
 };
 return {record,today:()=>summarizeCalls(read(now())),day:()=>easternDay(now())};
}

// Agent REST WebSocket uses the ADT+ agent session. The browser must be allowed to
// reach the Agent REST origin and send that session's credentials; no secrets are stored here.
export function watchAgentMetrics({apiBase,adapterUrl,onMetrics,onStatus,onObserver,onDiagnostics,onCallEvent,onIdentity,storage=window.localStorage}){
 let url;try{url=new URL(apiBase||adapterUrl);if(url.protocol!=='https:'||!/(^|\.)five9\.(com|net|eu)$/.test(url.hostname))throw Error();}catch{url=null};
 let closed=false,socket=null,ping=null,retry=null,dayTicker=null,attempt=0,ledger=null,activeAgent='',activeDomain='',pending=[],timingEvents=0,completedEvents=0,callEvents=0;
 const diagnostics=()=>onDiagnostics?.({callEvents,completedEvents,timingEvents,source:ledger?'CRM and WebSocket':'Waiting for call',agentScope:activeAgent?.startsWith('tab-')?'This browser tab':'Five9 agent ID'});
 const sessionAgent=(()=>{try{let id=sessionStorage.getItem('mortgage-metrics-tab-id');if(!id){id=globalThis.crypto?.randomUUID?.()||Math.random().toString(36).slice(2);sessionStorage.setItem('mortgage-metrics-tab-id',id)}return `tab-${id}`}catch{return `tab-${Math.random().toString(36).slice(2)}`}})();
 const observe=(call,finished=false)=>{
  if(!call?.id||!call.domainId)return;
  if(ledger&&activeAgent&&call.agentId&&String(call.agentId)!==activeAgent)return;
  if(!ledger){activeAgent=String(call.agentId||sessionAgent);activeDomain=String(call.domainId);ledger=createDailyLedger(storage,activeAgent,activeDomain);onMetrics(ledger.today());diagnostics();onStatus(url?'CRM call tracking; connecting to Five9 timing events':'CRM call tracking · set Agent REST URL for timing events');}
  if(String(call.domainId)!==activeDomain||call.agentId&&String(call.agentId)!==activeAgent)return;
  const type=call.direction==='Inbound'?'INBOUND':call.direction==='Outbound'?'OUTBOUND':'';
  if(!type)return;
  const result=ledger.record(finished?'5':'3',{id:call.id,callType:type,...(finished?{handleTime:call.handleTime,talkTime:call.talkTime,wrapupTime:call.wrapupTime}:{})});
  if(result?.day===ledger.day())onMetrics(result.summary);
  if(pending.length){const events=pending;pending=[];for(const event of events)processEvent(event)}
 };
 const processEvent=event=>{
  const eventId=String(event?.context?.eventId||'');if(!['3','4','5','30','31'].includes(eventId))return;
  callEvents++;if(['5','31'].includes(eventId))completedEvents++;
  const payload=event.payLoad||event.payload;
  if(['handleTime','talkTime','wrapupTime'].some(key=>ms(payload?.[key])>0))timingEvents++;
  diagnostics();
  if(!ledger){pending.push(event);if(pending.length>120)pending.shift();return}
  const result=ledger.record(eventId,payload);
  if(result){if(result.day===ledger.day())onMetrics(result.summary);if(!result.saved)onStatus('Metrics cannot be saved in this browser')}
 };
 onObserver?.(observe);
 if(!url)onStatus('Waiting for Five9 call; enter Agent REST base in Admin → Integrations for full timing');
 const shutdown=()=>{clearInterval(ping);clearInterval(dayTicker);clearTimeout(retry);if(socket){socket.onclose=null;socket.close();socket=null}};
 async function connect(){
  if(closed||!url)return;
  try{
   let host=url.hostname,metadataError='';
   try{
    const response=await fetch(`${url.origin}/appsvcs/rs/svc/auth/metadata?role=Agent`,{credentials:'include',cache:'no-store'});
    if(!response.ok)throw Error(`metadata HTTP ${response.status}`);
    const data=await response.json();const meta=data.metadata||data;
    host=meta.dataCenters?.find(center=>center.active)?.apiUrls?.[0]?.host||host;
    const metadataAgent=String(data.userId||data.token?.userId||meta.userId||'');
    const metadataDomain=String(data.orgId||data.token?.orgId||meta.orgId||'');
    if(metadataAgent&&metadataDomain)onIdentity?.({agentId:metadataAgent,domainId:metadataDomain});
    // The CRM observer may already have established today's call ledger. Never
    // replace it on a late metadata response or after a WebSocket reconnect.
    if(!ledger&&metadataAgent&&metadataDomain){activeAgent=metadataAgent;activeDomain=metadataDomain;ledger=createDailyLedger(storage,activeAgent,activeDomain);onMetrics(ledger.today());diagnostics()}
   }catch(error){metadataError=error.message}
   if(!host||!/(^|\.)five9\.(com|net|eu)$/.test(host))throw Error('active API host unavailable');
   clearInterval(dayTicker);dayTicker=setInterval(()=>{if(ledger)onMetrics(ledger.today())},60000);
   const wsKey=`mortgage-${globalThis.crypto?.randomUUID?.()||Math.random().toString(36).slice(2)}`;
   const ws=new WebSocket(`wss://${host}/appsvcs/ws/${encodeURIComponent(wsKey)}`);
   socket=ws;
   ws.onopen=()=>{attempt=0;onStatus(metadataError?`Five9 WebSocket open; REST metadata unavailable (${metadataError}); checking call events`:'Five9 WebSocket open; waiting for call events');ping=setInterval(()=>{if(ws.readyState===WebSocket.OPEN)ws.send('ping')},20000)};
   ws.onmessage=message=>{let event;try{event=JSON.parse(message.data)}catch{return}if(['3','4','5','30','31'].includes(String(event.context?.eventId||''))){onStatus('Receiving Five9 call events');onCallEvent?.(event)}processEvent(event)};
   ws.onerror=()=>onStatus('Five9 event connection interrupted');
   ws.onclose=event=>{clearInterval(ping);if(closed)return;onStatus(`Five9 events disconnected${event.code===3001?' (WebSocket connection limit reached)':''}; reconnecting`);retry=setTimeout(connect,Math.min(30000,1000*2**Math.min(attempt++,5)))};
  }catch(error){if(closed)return;onStatus(`Call counts via CRM; Five9 timing unavailable: ${error.message}. Check Agent REST access.`);retry=setTimeout(connect,Math.min(30000,1000*2**Math.min(attempt++,5)))}
 }
 connect();
 return ()=>{closed=true;onObserver?.(null);shutdown()};
}
