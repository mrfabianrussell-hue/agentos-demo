// Read-only Five9 CRM SDK observer. No CRM callbacks, writes, dispositions, or logs.
const valueOf = field => String(field?.value ?? field?.fieldValue ?? '');

export function watchFive9({onCall,onStatus,onEnd}){
  const sdk = window.Five9?.CrmSdk;
  if(!sdk?.interactionApi){onStatus('Five9 CRM SDK did not load. Check the browser network and approved CDN access.');return;}
  let api;
  try{api=sdk.interactionApi()}catch{onStatus('CRM SDK is present but could not initialize.');return;}
  onStatus('Listening for Five9 call events. Place a test call in ADT.');
  let currentId=null;
  async function started({callData}={},accepted=false){
    const id=callData?.interactionId;
    if(!id)return;
    currentId=id;
    const direction=/^(INBOUND|QUEUE_CALLBACK)/.test(callData.callType||'')?'Inbound':'Outbound';
    onCall({id,direction,domainId:String(callData.domainId||callData.domainName||'unknown'),domainName:callData.domainName||'',callType:callData.callType||'Unknown',campaign:callData.campaignName||'',campaignId:String(callData.campaignId||''),agentId:String(callData.agentId||''),callState:accepted?'TALKING':callData.state||'',ani:String(callData.ani||callData.ANI||''),fields:[],fieldNames:[]});
    const [cav,crm]=await Promise.allSettled([
      api.getCav({interactionId:id,interactionSubType:callData.interactionSubType}),
      api.getCrm({interactionId:id})
    ]);
    if(currentId!==id)return;
    const cavFields=cav.status==='fulfilled'&&Array.isArray(cav.value)?cav.value:[];
    const crmFields=crm.status==='fulfilled'&&Array.isArray(crm.value)?crm.value:[];
    const fields=[...cavFields.map(field=>({...field,source:'cav'})),...crmFields.map(field=>({...field,source:'crm'}))].map(field=>({name:String(field.name||field.displayName||''),value:valueOf(field),source:field.source})).filter(field=>field.name);
    const fieldNames=[...new Set(fields.map(field=>field.name))].sort();
    onCall({id,direction,domainId:String(callData.domainId||callData.domainName||'unknown'),domainName:callData.domainName||'',callType:callData.callType||'Unknown',campaign:callData.campaignName||'',campaignId:String(callData.campaignId||''),agentId:String(callData.agentId||''),callState:accepted?'TALKING':callData.state||'',ani:String(callData.ani||callData.ANI||''),fields,fieldNames});
  }
  function finished({callData}={}){if(callData?.interactionId===currentId){currentId=null;onEnd(callData.interactionId,callData)}}
  try{api.subscribe({callStarted:started,callAccepted:event=>started(event,true),callFinished:finished});}
  catch{onStatus('Could not subscribe to Five9 call events. Verify the adapter CRM API setting.');}
}
