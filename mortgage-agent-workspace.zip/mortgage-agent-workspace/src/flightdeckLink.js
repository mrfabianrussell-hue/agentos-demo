export const DEFAULT_FLIGHTDECK='/flightdeck/index.html';
export const TASKS=[['transfer','New to servicing'],['paymentChange','Why payment changed'],['payment','Find or make payment'],['originations','Originations'],['escrow','Escrow'],['insurance','Insurance'],['contact','Contact information']];
const SAFE_UTTERANCES=new Set(['need to make a payment','i need to make a payment','i want to make a payment','make a payment','escrow balance is wrong','my escrow balance is wrong','my escrow balance is incorrect','why did my payment go up','my payment went up','my mortgage payment increased','my payment is missing','my payment is not showing','i was charged twice','i want to pay my escrow shortage','i need to pay my escrow shortage']);
export function flightDeckUrl(config={},task='',context={}){
 const raw=(config.flightDeckUrl||DEFAULT_FLIGHTDECK).trim();
 let url;
 try{url=new URL(raw,globalThis.location?.href||'http://localhost:5173/')}catch{return null}
 const local=url.origin===(globalThis.location?.origin||'http://localhost:5173');
 if(!local&&url.protocol!=='https:')return null;
 if(url.username||url.password)return null;
 url.search='';url.hash='';
 const rule=(config.flightDeckRoutes||[]).find(x=>x.task===task);
 if(rule?.subjectId?.trim())url.searchParams.set('subjectId',rule.subjectId.trim());
 else {
  const intent=(rule?.intent||({paymentChange:'payment_increase',payment:'make_payment',escrow:'escrow',insurance:'homeowners_insurance'}[task]||'')).trim();
  if(intent)url.searchParams.set('Intent',intent);
  if(context.kind==='outbound'&&context.campaign)url.searchParams.set('OBCampaignName',String(context.campaign).slice(0,120));
  else if(context.kind!=='outbound'&&context.reason){const phrase=String(context.reason).trim().toLowerCase();if(SAFE_UTTERANCES.has(phrase))url.searchParams.set('IBUtterance',phrase)}
 }
 return url.href;
}
