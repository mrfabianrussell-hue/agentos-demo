// A live Five9 contact is not a servicing loan record. These are UI placeholders only.
const awaiting='Awaiting data connection';
export function liveLoan(contact,identifier='',propertyState=''){
 const id=contact?.loanNumber||identifier||'Loan number unavailable';
 return {id,name:contact?.name||'Contact not selected',phone:contact?.phones?.join(' · ')||awaiting,email:awaiting,property:awaiting,propertyState,status:'Servicing data pending',balance:awaiting,rate:awaiting,payment:awaiting,due:awaiting,principal:awaiting,interest:awaiting,escrow:awaiting,lastPayment:awaiting,lastPaymentAmount:awaiting,escrowBalance:awaiting,taxes:awaiting,insurance:awaiting,shortage:awaiting,transfer:null,loanType:awaiting,insuranceStatus:awaiting,lossMit:awaiting,alerts:[],history:[],escrowChange:{recurring:awaiting,temporary:awaiting,newPayment:awaiting,effective:awaiting,taxes:awaiting,insurance:awaiting,priorTaxes:awaiting,priorInsurance:awaiting}};
}
