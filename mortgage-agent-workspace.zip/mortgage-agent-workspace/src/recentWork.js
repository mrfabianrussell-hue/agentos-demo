const KEY='mortgage-workspace-recent-v1';
const DAY=24*60*60*1000;
export function readRecent(storage=localStorage,now=Date.now()){
 try{return (JSON.parse(storage.getItem(KEY)||'[]')||[]).filter(item=>item&&typeof item==='object'&&Number(item.at)>now-DAY&&Number(item.at)<=now+60000).sort((a,b)=>b.at-a.at).slice(0,30)}catch{return []}
}
export function saveRecent(item,storage=localStorage,now=Date.now()){
 if(!item?.id)return readRecent(storage,now);
 const row={id:String(item.id),at:now,kind:['call','lookup','sample'].includes(item.kind)?item.kind:'lookup',direction:String(item.direction||'').slice(0,24),loanNumber:String(item.loanNumber||'').slice(0,50),contactId:String(item.contactId||'').slice(0,80),name:String(item.name||'').slice(0,100),domainId:String(item.domainId||'').slice(0,80),task:String(item.task||'').slice(0,40)};
 const rows=[row,...readRecent(storage,now).filter(old=>old.id!==row.id)].slice(0,30);
 try{storage.setItem(KEY,JSON.stringify(rows))}catch{}
 return rows;
}
export function clearRecent(storage=localStorage){try{storage.removeItem(KEY)}catch{}return []}
