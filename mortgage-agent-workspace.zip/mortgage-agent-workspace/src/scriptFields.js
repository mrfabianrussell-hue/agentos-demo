// Stable script keys are mapped to each domain in Admin. Never turn a contact match into verification.
export const builtinFields=[
 {key:'businessName',label:'Approved business name',source:'client',fallback:'our servicing team'},
 {key:'agentName',label:'Agent name',source:'workspace',fallback:'your agent'},
 {key:'customerName',label:'Customer name',source:'contact',fallback:'the account holder'},
 {key:'reason',label:'Call reason',source:'call',fallback:'your request'},
 {key:'contact.loanNumber',label:'Contact loan number',source:'contact',fallback:'loan number unavailable',protected:true},
 {key:'call.campaign',label:'Campaign',source:'call',fallback:'the current campaign'},
 {key:'call.reason',label:'Clara or call reason',source:'call',fallback:'your request'}
];
export function resolveClient(config,{domainId='',campaign='',loanNumber='',fields=[]}={}){
 const normalized=s=>String(s||'').trim().toLowerCase();
 const candidates=(config.clients||[]).filter(item=>item.enabled!==false&&!!String(item.matchValue||'').trim()&&(!item.domainId||normalized(item.domainId)===normalized(domainId))&&(
  item.matchType==='field'?fields.some(f=>normalized(f.name)===normalized(item.matchField)&&normalized(f.value)===normalized(item.matchValue)):
  item.matchType==='campaign'?normalized(campaign)===normalized(item.matchValue):
  item.matchType==='loanPrefix'?!!loanNumber&&String(loanNumber).startsWith(String(item.matchValue||'__none__')):false
 ));
 return candidates.length===1?{status:'matched',client:candidates[0]}:{status:candidates.length?'ambiguous':'unmatched',client:null};
}
export function scriptValues(config,{agent,contact,context,reason,client}={}){
 const raw={businessName:client?.spokenName||config.businessName,agentName:agent?.name,customerName:contact?.name,reason,'contact.loanNumber':contact?.loanNumber,'call.campaign':context?.campaign,'call.reason':reason};
 for(const rule of config.scriptFields||[]){
  if(!rule.key||!rule.fieldName||builtinFields.some(f=>f.key===rule.key)||rule.domainId&&String(rule.domainId)!==String(context?.domainId))continue;
  const field=context?.fields?.find(f=>String(f.name).toLowerCase()===String(rule.fieldName).toLowerCase()&&(!rule.source||rule.source==='any'||f.source===rule.source));
  if(field?.value)raw[rule.key]=String(field.value).slice(0,200);
 }
 return raw;
}
export function scriptIssues(config,text,values){
 return [...String(text||'').matchAll(/\{([^{}]+)\}/g)].map(m=>m[1]).filter(key=>!(config.scriptFields||[]).some(f=>f.key===key)&&!builtinFields.some(f=>f.key===key)).map(key=>`Unknown field: {${key}}`)
  .concat([...String(text||'').matchAll(/\{([^{}]+)\}/g)].map(m=>m[1]).filter(key=>values[key]==null||values[key]==='').map(key=>`Fallback used: {${key}}`));
}
