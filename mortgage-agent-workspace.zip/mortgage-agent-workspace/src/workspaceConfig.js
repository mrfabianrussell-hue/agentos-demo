const KEY='mortgage-workspace-admin-v1';
export const defaultConfig={
  roles:[{id:'admin',name:'Administrator',permissions:['users','sites','clients','integrations','scripts']},{id:'script_editor',name:'Script editor',permissions:['scripts']},{id:'supervisor',name:'Supervisor',permissions:[]},{id:'agent',name:'Agent',permissions:[]}],
  users:[{id:'demo-agent',name:'Demo Agent',five9User:'',role:'admin',siteId:'demo-site',active:true}],
  sites:[{id:'demo-site',name:'Demo servicing site',states:['NC'],active:true,transferLabel:'Approved servicing queue'}],
  scripts:[
    {id:'opening',name:'Clara opening',text:'Thank you for calling {businessName}. My name is {agentName}. I see you were speaking with Clara about {reason}. I’ll be glad to help. Am I speaking with {customerName}?',version:1},
    {id:'opening-fallback',name:'Opening without Clara reason',text:'Thank you for calling {businessName}. My name is {agentName}. I’ll be glad to help. Am I speaking with {customerName}?',version:1},
    {id:'manual-auth',name:'Manual authentication',text:'Before we discuss the loan, I need to complete our authentication process.',version:1},
    {id:'agent-verify',name:'Agent verification',text:'Thank you. I’ll complete a final verification step before we discuss your account.',version:1},
    {id:'state-transfer',name:'State servicing exception',text:'Let me connect you with the team that can assist with this account.',version:1},
    {id:'callback-opening',name:'Queue callback opening',text:'Hi, this is {agentName} from {businessName}, returning your call. Am I speaking with {customerName}?',version:1},
    {id:'outbound-opening',name:'Outbound opening',text:'Hi, this is {agentName} from {businessName}. May I speak with {customerName}?',version:1},
    {id:'outbound-purpose',name:'Outbound reason after name confirmation',text:'I’m calling about {reason}. Is this a good time to speak?',version:1},
    {id:'callback-purpose',name:'Callback reason after name confirmation',text:'I’m returning your call about {reason}. I’ll be glad to help.',version:1}
  ],
  businessName:'Harbor Mortgage Servicing',
  clients:[],
  scriptFields:[],
  five9ApiBase:'',
  flightDeckUrl:'/flightdeck/index.html',
  flightDeckRoutes:[],
  five9DomainId:'',
  campaignRules:[{id:'demo-payment-followup',domainId:'demo',campaignId:'',campaignName:'OB – PAYMENT FOLLOW-UP',purpose:'your recent payment',verification:'Confirm the named customer answered. Follow your approved process before protected account details.'}],
  callDestinations:[],
  closeoutRules:[],
  demoUserId:'demo-agent',
  metricsSource:'demo',
  competitionEnabled:false,
  targetHandleSeconds:330,
  approvedTransferLabel:'Approved servicing queue'
};
function clean(value){
  if(!value||typeof value!=='object'||Array.isArray(value))return structuredClone(defaultConfig);
  return {...structuredClone(defaultConfig),...value,users:Array.isArray(value.users)?value.users:defaultConfig.users,sites:Array.isArray(value.sites)?value.sites:defaultConfig.sites,scripts:[...defaultConfig.scripts.filter(s=>!Array.isArray(value.scripts)||!value.scripts.some(old=>old.id===s.id)),...(Array.isArray(value.scripts)?value.scripts:[])],roles:Array.isArray(value.roles)?value.roles:defaultConfig.roles,campaignRules:Array.isArray(value.campaignRules)?value.campaignRules:defaultConfig.campaignRules,callDestinations:Array.isArray(value.callDestinations)?value.callDestinations:[],closeoutRules:Array.isArray(value.closeoutRules)?value.closeoutRules:[],clients:Array.isArray(value.clients)?value.clients:[],scriptFields:Array.isArray(value.scriptFields)?value.scriptFields:[],flightDeckRoutes:Array.isArray(value.flightDeckRoutes)?value.flightDeckRoutes:[]};
}
export function loadConfig(){try{return clean(JSON.parse(localStorage.getItem(KEY)))}catch{return clean(null)}}
export function saveConfig(value){const next=clean(value);localStorage.setItem(KEY,JSON.stringify(next));return next}
export function renderScript(config,id,vars={}){
 const source=config.scripts.find(item=>item.id===id)?.text||'';
 const fallbacks={businessName:'our servicing team',agentName:'your agent',reason:'your request',customerName:'the account holder'};
 return source.replace(/\{([^{}]+)\}/g,(_,key)=>{
  const field=(config.scriptFields||[]).find(item=>item.key===key);
  const protectedBuiltin=key==='contact.loanNumber';
  const raw=vars[key];
  if((field?.protected||protectedBuiltin)&&!vars.__verified)return '[available after verification]';
  return String(raw!==undefined&&raw!==null&&raw!==''?raw:field?.fallback||fallbacks[key]||'[field unavailable]').slice(0,250);
 });
}
export function eligibility(config,agent,propertyState){
  const site=config.sites.find(item=>item.id===agent?.siteId&&item.active);
  if(!agent?.active||!site||!propertyState)return {status:'unknown',site,reason:'Site or property state is unavailable'};
  return (site.states||[]).includes(propertyState.toUpperCase())?{status:'allowed',site,reason:'Servicing permitted at assigned site'}:{status:'restricted',site,reason:`${site.name} is not configured to service ${propertyState.toUpperCase()} accounts`};
}
export const states='AL AK AZ AR CA CO CT DE DC FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY'.split(' ');
